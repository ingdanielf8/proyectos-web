module.exports = 'Cálculo y medición de magnitudes eléctricas y electrónicas'
