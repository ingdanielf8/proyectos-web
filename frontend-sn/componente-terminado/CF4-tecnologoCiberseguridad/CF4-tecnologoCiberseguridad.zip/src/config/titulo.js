module.exports = 'Diseño y documentación de controles de ciberseguridad'
