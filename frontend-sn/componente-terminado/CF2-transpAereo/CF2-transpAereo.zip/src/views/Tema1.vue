<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 1
      h1 	Transporte aéreo

    figure
      img(src="@/assets/template/tema-1-1.png", alt="Texto que describa la imagen")
    p.mt-5 La economía del país se dinamiza a partir de las actividades de los diferentes sectores que la integran, es así como el turismo y el transporte aéreo se convierten en parte fundamental del desarrollo local y regional, ya que obligan al Estado a invertir recursos para la adecuación de la planta turística, generando empleo y por tanto mejorando la calidad de vida de los participantes en el proceso, el medio aeronáutico y la actividad turística, empresarial y social.
    figure.mt-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/2L91WMqw96A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    .titulo-segundo.mt-5
      #t_1_1.h4 1.1  Organismos reguladores de la aviación (IATA, OACI)
    figure.mt-4
      img(src="@/assets/template/tema-1-2.png", alt="Texto que describa la imagen")
    .h4.mt-5 OACI: Organización de Aviación Civil Internacional (en inglés International Civil Aviation Organization. ICAO)
    .row.mt-5
      .col-12.col-lg-8
        p Organización creada por la ONU (Organización de Naciones Unidas) en 1944 por el convenio sobre la aviación civil internacional que pretendía revisar y promover reglas y normas únicas en la aeronáutica alrededor del mundo.
        p Los miembros activos en esta entidad son alrededor de 193 actualmente, su sede principal es en Montreal, Canadá, sin embargo, tiene otra sucursal en París.
        p.mt-4 Es responsable de:
          ul.lista-ul.mt-4
            li 
              i.fas.fa-angle-right
              | Una aviación civil internacional ordenada.
            li.mt-2
              i.fas.fa-angle-right
              | De las normas técnicas del diseño y manejo de aeronaves.
            li.mt-2
              i.fas.fa-angle-right
              | Evitar la discriminación de entre los estados contratantes de servicios de aviación civil.
            li.mt-2
              i.fas.fa-angle-right
              | La seguridad en navegación aérea internacional.
            li.mt-2
              i.fas.fa-angle-right
              | Apoyar en la creación de rutas, aeropuertos y navegación.
            li.mt-2
              i.fas.fa-angle-right
              | Fomentar el desarrollo de las regiones.
            li.mt-2
              i.fas.fa-angle-right
              | Evitar el despilfarro de recursos por competencia desleal.
            li.mt-2
              i.fas.fa-angle-right
              | Creación del alfabeto aeronáutico o fonético, ya que es la manera de comunicación más efectiva en el medio aeronáutico para garantizar que todos hablen el mismo idioma.
      .col-6.col-lg-4.offset-6.offset-lg-0.align-self-center
        figure
          img(src="@/assets/template/tema-1-3.png", alt="Texto que describa la imagen")
    p.mt-5 Para el año 2030, la OACI ha considerado los siguientes objetivos estratégicos:
    .row.mt-5
      .col-10.offset-1
        LineaTiempoD.color-primario
          .row(numero="1" titulo="Seguridad operacional")
            .col-2.col-lg-1
              figure
                img(src="@/assets/template/tema-1-4.svg", alt="Texto que describa la imagen")
            .col-10.col-lg-11
              p Se centra en el Plan Global para la (GASP).

          .row(numero="2" titulo="Capacidad y eficiencia de la navegación aérea")
            .col-2.col-lg-1
              figure
                img(src="@/assets/template/tema-1-5.svg", alt="Texto que describa la imagen")
            .col-10.col-lg-11
              p Modernización de infraestructura y elaboración de nuevos procedimientos con mayor eficiencia.
          .row(numero="3" titulo="Seguridad de la aviación y facilitación")
            .col-2.col-lg-1
              figure
                img(src="@/assets/template/tema-1-6.svg", alt="Texto que describa la imagen")
            .col-10.col-lg-11
              p Seguridad en la aviación y en la seguridad en fronteras.
          .row(numero="4" titulo="Desarrollo económico del transporte aéreo")
            .col-2.col-lg-1
              figure
                img(src="@/assets/template/tema-1-7.svg", alt="Texto que describa la imagen")
            .col-10.col-lg-11
              p Sistema de aviación sólido económicamente construido con políticas y actividades de apoyo.
          .row(numero="5" titulo="Protección del medio ambiente")
            .col-2.col-lg-1
              figure
                img(src="@/assets/template/tema-1-8.svg", alt="Texto que describa la imagen")
            .col-10.col-lg-11
              p Promover actividades relacionadas entre el medio ambiente y la aviación, con prácticas y políticas de protección del medio ambiente.
    .h4.mt-5 IATA: Asociación Internacional de Transporte Aéreo (en inglés International Air Transport Association)
    .row.mt-5
      .col-12.col-lg-9
        p Fundada en el año 1919 en La Haya por 31 naciones y 57 aerolíneas, conocida en ese entonces como la asociación internacional de tráfico aéreo, con el pasar de los años en 1944 en la convención de Chicago, se reinauguró incluyendo América y el resto del mundo.
        p.mt-3 Su objetivo principal y razón por la que fue creada es la promoción de la seguridad, confianza, fiabilidad y sobre todo el cooperativismo entre líneas aéreas, para pertenecer a la IATA, las aerolíneas deben estar adscritas a las IOSA (IATA Operational Safety Audit), en el caso que las aerolíneas tengan dentro de sus rutas vuelos internacionales, para las que operan a nivel nacional pueden asociarse con la condición de tener voz, pero no voto en la organización.
      .col-6.col-lg-3.offset-6.offset-lg-0
        figure
          img(src="@/assets/template/tema-1-9.png", alt="Texto que describa la imagen")
    p.mt-4 La misión de esta entidad es representar las aerolíneas, actualmente se encuentran activas 290 alrededor del mundo y aproximadamente el 94 % de estas operan vuelos internacionales, la IATA ayuda a maximizar los procesos y a que sean más eficientes financieramente hablando, también participa en ofrecer garantías a todos actores que participan en el comercio aéreo.
    p.mt-5 Es responsable de:
    .row.mt-4
      .col-12.col-lg-9
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right
            | Simplificar los procesos de viaje y transporte, mientras mantiene los costos bajos.
          li.mt-2
            i.fas.fa-angle-right
            | Permitir operar de forma segura, eficiente y económica, bajo reglas definidas a las aerolíneas.
          li.mt-2
            i.fas.fa-angle-right
            | Servir de intermediario entre el pasajero, los agentes de carga y las aerolíneas.
          li.mt-2
            i.fas.fa-angle-right
            | Proveer servicios y una variedad de soluciones industriales. 
          li.mt-2
            i.fas.fa-angle-right
            | Asegurar que los entes gubernamentales puedan estar bien informados de las complejidades de la industria de la aviación.
      .col-4.col-lg-3.offset-4.offset-lg-0.align-self-center
        figure
          img(src="@/assets/template/tema-1-10.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
    .h4.mt-5 Códigos IATA
    figure.mt-4
      img(src="@/assets/template/tema-1-11.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.col-lg-8
        p Son códigos alfabéticos usando los 26 caracteres del alfabeto latino. Estos códigos se asignan principalmente a ciudades y aeropuertos, son usados para las tarjetas de embarque, pantallas informativas y etiquetas que marcan el equipaje para su ubicación inmediata en aeropuertos no sistematizados.
        p.mt-3 El código de aeropuertos y ciudades corresponde a tres letras, por ejemplo, Bogotá que cuenta con un solo aeropuerto maneja el mismo código IATA que es BOG. En el caso de Medellín que cuenta con dos aeropuertos tendrá un código para el aeropuerto internacional y un código para el aeropuerto regional respectivamente, así: Aeropuerto Internacional de Rionegro con el código MDE y aeropuerto regional Enrique Olaya Herrera con el código EOH.
      .col-6.col-lg-4
        figure
          img(src="@/assets/template/tema-1-12.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-8.offset-2
        .bloque-texto-g.color-primario.p-3.p-sm-4.p-md-4.mb-5
          .bloque-texto-g__img(
            :style="{'background-image': `url(${require('@/assets/template/tema-1-13.png')})`}")
          .bloque-texto-g__texto.p-4
            p.mb-0 Por otra parte, los códigos IATA también son muy usados en los sistemas de reservas para documentar procesos, de tal manera que se usa el código IATA del país que corresponde a dos letras, ejemplo, para Colombia CO, para Brasil BR, para Chile CL. 
    .row.mt-5
      .col-10.offset-1
        .tarjeta.color-primario.p-4.mb-5.bg-amarillo-gradiente
          .row.justify-content-around.align-items-center
            .col-3.col-sm-2.col-lg-1
              img(src="@/assets/template/tema-1-14.svg")
            .col
              .row.justify-content-between.align-items-center
                .col.mb-3.mb-sm-0
                  h3.mb-1 Código IATA: aeropuertos
                  p.text-small Los códigos de los principales aeropuertos del mundo se pueden consultar a través de este enlace:
                .col-sm-auto
                  a.boton.color-acento-contenido.texto-blanco(:href="obtenerLink('/downloads/prueba.pdf')" target="_blank")
                    span Enlace web
                    i.fas.fa-link
    .row
      .col-10.offset-1
        .tarjeta.color-primario.p-4.mb-5.bg-morado-gradiente
          .row.justify-content-around.align-items-center
            .col-3.col-sm-2.col-lg-1
              img(src="@/assets/template/tema-1-15.svg")
            .col
              .row.justify-content-between.align-items-center
                .col.mb-3.mb-sm-0
                  h3.mb-1.text-white Código IATA: ciudad y país
                  p.text-small.text-white Para ampliar la información de códigos IATA de ciudades y países, descargue el siguiente documento.
                .col-sm-auto
                  a.boton.color-acento-contenido.texto-blanco(:href="obtenerLink('/downloads/prueba.pdf')" target="_blank")
                    span Descargar
                    i.fas.fa-file-download
    .row.mt-4
      .col-6.col-lg-4.offset-6.offset-lg-0
        figure
          img(src="@/assets/template/tema-1-16.png", alt="Texto que describa la imagen")
      .col-12.col-lg-8
        p En Colombia la entidad encargada de regular la actividad aérea es la Aeronáutica Civil de Colombia (Aerocivil).
        p Fue fundada por medio de la Ley 126 de 1919 por el Estado colombiano, la Unidad Administrativa Especial de Aeronáutica Civil o Aeronáutica Civil, que se encarga de vigilar, reglamentar y controlar la aviación en Colombia, además de administrar el espacio aéreo del Estado, también garantiza una infraestructura ambientalmente sostenible.
        p.mt-4 Es responsable de:
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .cajon.color-acento-botones.p-4.mb-4.bg-primario-5
          p.mb-0.px-4.py-3 Intervenir en el entorno de una competencia sana, segura en favor de los usuarios de este tipo de transporte, velando porque se cumplan sus derechos y cumplan con sus deberes. 
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .cajon.color-acento-botones.p-4.mb-4.bg-primario-2
          p.mb-0.px-4.py-3 Fijar y desarrollar todo lo concerniente a tarifas, en materia de transporte aéreo nacional e internacional y sancionar su violación.
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .cajon.color-acento-botones.p-4.mb-4.bg-primario-1
          p.mb-0.px-4.py-3 Manejar los derechos por la prestación de los servicios aeronáuticos y aeroportuarios o los que se generen por las concesiones, autorizaciones, licencias.
    p.mt-5 De otra parte, al igual que existe un marco regulatorio y cada entidad lleva a cabo acciones en pro de la seguridad en la aviación mundial, también existen convenios que se crearon con el fin de trabajar en temas puntuales para definir normas mínimas comunes para todos los participantes, esto lleva a la realización de acuerdos particulares entre países, sobre algunos aspectos en la normativa general.
    AcordionA.mb-5(tipo="b" clase-tarjeta="tarjeta tarjeta--azul bg-amarillo-claro").mt-4
      .row(titulo="Convenio de Varsovia").bg-amarillo-claro
        p Creado en octubre de 1929, trata el transporte aéreo como un contrato que tiene en cuenta todas las partes que son partícipes de este servicio, tiene como características principales:
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right
            | La importancia del tiquete y la carta de porte aéreo.
          li.mt-2
            i.fas.fa-angle-right
            | Emisión de tiquetes aéreos mediante la responsabilidad de las líneas aéreas. 
          li.mt-2
            i.fas.fa-angle-right
            | Emisión de un contrato de transporte que convienen las partes (aerolínea - usuario).
          li.mt-2
            i.fas.fa-angle-right
            | Responsabilidades del transportador en caso de no cumplimiento del servicio.
          li.mt-2
            i.fas.fa-angle-right
            | Garantía del equipaje facturado por parte de la línea aérea.
      div(titulo="Convenio de Chicago")
        p Creado en octubre de 1929, trata el transporte aéreo como un contrato que tiene en cuenta todas las partes que son partícipes de este servicio, tiene como características principales:
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right
            | #[strong Primero:] navegación, nacionalidad y condiciones de aeronaves.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Segundo:] creación de la OACI y sus características.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Tercero:] infraestructura aérea y todo lo que esto conlleva.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Cuarto:] recomendaciones para la firma de acuerdos.
      div(titulo="Libertades del aire")
        p En la aviación comercial es la normativa que garantiza a las aerolíneas entrar en el espacio aéreo de un país y aterrizar o no en este. Es el instrumento utilizado para la creación de rutas aéreas internacionales, ya que para esto las líneas aéreas requieren la aprobación de los Estados involucrados para que esta pueda sobrevolar dentro o fuera de un país o incluso volar sobre una nación sin aterrizar. 
        p.mt-3 A continuación, se explica cuáles son esas libertades:
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right
            | #[strong Primera libertad:] derecho de volar el territorio de un estado sin la necesidad de aterrizar en él.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Segunda libertad:] derecho de aterrizar en el territorio de un estado para fines técnicos (mantenimiento, combustible).
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Tercera libertad:] derecho de desembarque de pasajeros, carga y correo, procedentes del país de origen de la línea aérea.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Cuarta libertad:] derecho del embarque de pasajeros, carga y correo, con destino el país de la línea aérea.
          li.mt-2
            i.fas.fa-angle-right
            | #[strong Quitan libertad:] derecho de embarcar y desembarque de pasajeros, carga y correo, en cualquier ciudad de una ruta directa.
    
    .titulo-segundo.mt-5
      #t_1_2.h4 1.2  (tipos, características, generalidades)
    figure
      img(src='@/assets/template/tema-1-17.png', alt='Texto que describa la imagen')
    .row.mt-5
      .col-12.col-lg-9
        p El mundo de las aerolíneas es complejo por todo lo que ello envuelve, las aerolíneas se dedican al transporte de carga o pasajeros principalmente, muchas tienen participación del Estado y en casi todos los casos mantienen un monopolio del mercado, estas son denominadas como aerolíneas bandera en las naciones, sin embargo, algunas fueron privatizadas lo que dio pie a la aparición de otras aerolíneas en el mercado y una amplia gama de opciones para los clientes, dando lugar a una competencia entre operadores aéreos, aunque en algunos países las líneas aéreas hayan dejado de ser parte del Estado mantienen su liderato y dominio en el mercado, ejemplo, Air France (Francia), AlItalia (Italia), Avianca (Colombia).
        p.mt-4 Se encuentran así tipos de aerolíneas como se puede observar en la tabla 1:
      .col-4.col-lg-3.offset-4.offset-lg-0
        figure
          img(src="@/assets/template/tema-1-18.svg", alt="Texto que describa la imagen")  
    .titulo-sexto.color-acento-contenido
      p Tabla 1
    .tabla-b.color-secundario.mb-5
      table
        tr.bg-secundario.text-center
          th 
            .h3.mb-0 Tipología
          td 
            .h3.mb-0 Característica principal
        tr
          th Compañía aérea principal
          td 
            p Manejan rutas troncales nacionales e internacionales, con el mayor número de pasajeros, carga, por lo general están asociados a la IATA. 
            p.mt-3 Usualmente posee una flota grande de aeronaves y maneja unos planes de vuelo establecidos.
        tr
          th Compañía aérea complementaria
          td Operan rutas secundarias, menor movilidad de operación, menor capacidad operativa en cuanto a cantidad de aeronaves.
        tr
          th Compañía aérea regular
          td Servicios regulares teniendo en cuenta el plan de ruta, escalas, tarifas, fechas, normalmente es para las compañías del estado, aunque en los últimos años aplica también a las líneas aéreas mixtas y privadas.
        tr
          th Compañía aérea chárter
          td 
            p Es un servicio no regular, que se pacta a necesidad del cliente entre operador y usuario, normalmente se alquila todo lo pertinente en un proceso de vuelo (tripulación, mantenimiento etc.), este tipo de servicio suele incrementarse en temporada alta.
            p Suele tener menos gastos en servicio a bordo, menos gastos administrativos, manejan sistemas que eliminan los tiempos de espera en los aeropuertos.
            p.mt-3 Paquetes todo incluido, donde el operador del plan ofrece este servicio junto con el hotel, actividades turísticas, traslados en el destino.
            p.mt-3 Corporativos o naturales: son servicios solicitados por una persona natural o jurídica que alquila la aeronave.
        tr
          th Compañía aérea low cost 
          td 
            p Funciona bajo el modelo de venta de servicios adicionales al tiquete, por tanto, el valor de las tarifas del tiquete será inferior, razón por la cual funciona al mínimo servicio, no incluye servicios gratuitos y operan al mínimo de tripulantes de cabina y demás costos.
            p.mt-3 Se basan principalmente en operar solo rutas de alta demanda y con los menores costos operativos posibles.
        tr
          th Compañía aérea de bandera
          td 
            p Es la que designa el gobierno para manejar los derechos de tráfico asignados, puede ser una o varias aerolíneas denominadas con este nombre.
            p.mt-3 Actualmente este concepto casi no se usa ya que esta figura está siendo reemplazada por la multi designación, que significa nombrar varias líneas aéreas para operar en rutas con acuerdos bilaterales entre Gobiernos.
        tr
          th Compañía aérea de fomento
          td Generalmente son compañías aéreas del estado, donde su finalidad es la conectividad de ciudadanos a destinos a los que las aerolíneas convencionales no llegan, también, puede operar para prestar servicios como, abastecimiento alimenticio, medicamentos o transporte de pacientes.
        tr
          th Compañía aérea de carga
          td Se denominan de carga a las compañías aéreas de mercancía, es parte fundamental en la red internacional de logística, ya que es parte vital en los procesos de importación y exportación. 
    .titulo-segundo.mt-5
      #t_1_3.h4 1.3  Alianzas aéreas de conectividad
    .row.mt-4
      .col-12.col-lg-9
        p Una alianza aérea es un acuerdo de colaboración entre aerolíneas, para garantizar la conectividad, en este momento hay activas tres grandes alianzas aéreas mundiales que son:
        ul.lista-ul.mt-4
          li 
            i.fas.fa-angle-right
            | Star Alliance
          li.mt-2
            i.fas.fa-angle-right
            | SkyTeam 
          li.mt-2
            i.fas.fa-angle-right
            | Oneworld
        p.mt-3 Las alianzas buscan el beneficio tanto de los viajeros como de las aerolíneas mismas, logrando para los pasajeros llegar a destinos a los que tal vez no sería tan fácil o no se pudiera llegar si no participan 2 o más aerolíneas en el trayecto y para las líneas aéreas porque pueden tener acceso a un nuevo mercado aumentando la comercialización de su servicio. Estas alianzas se realizan generalmente a través de acuerdos de código compartido. 
      .col-6.col-lg-3.offset-6.offset-lg-0
        figure
          img(src="@/assets/template/tema-1-19.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.borde-gris-claro.p-4.rounded-20
        .row
          .col-4.d-none.d-lg-block.borde-gris-der
            figure.align-self-center.mt-5
              img(src="@/assets/template/tema-1-20.svg", alt="Texto que describa la imagen")
          .col-12.col-lg-8.py-4.px-5
            .h3 Entre los beneficios para las aerolíneas se tiene
            ul.lista-ul.mt-4
              li 
                i.fas.fa-angle-right
                | Oficinas de ventas.
              li.mt-2
                i.fas.fa-angle-right
                | Instalaciones de mantenimiento.
              li.mt-2
                i.fas.fa-angle-right
                | El personal. Por ejemplo, personal de tierra, en los mostradores de facturación y en los mostradores de embarque.
              li.mt-2
                i.fas.fa-angle-right
                | Precios más bajos por reducción de gastos de funcionamiento para una determinada ruta.
    .row.mt-5
      .col-12.borde-gris-claro.p-4.rounded-20
        .row
          .col-4.d-none.d-lg-block.borde-gris-der.pt-3
            figure.align-self-center
              img(src="@/assets/template/tema-1-40.svg", alt="Texto que describa la imagen")
          .col-12.col-lg-8.py-4.px-5
            .h3 Los beneficios para los viajeros son
            ul.lista-ul.mt-4
              li 
                i.fas.fa-angle-right
                | Opciones de poder elegir más horarios en la ruta que se necesita.
              li.mt-2
                i.fas.fa-angle-right
                | Más destinos pueden ser combinados fácilmente, de acuerdo con sus necesidades.
              li.mt-2
                i.fas.fa-angle-right
                | Optimización en los tiempos de las conexiones entre vuelos.
    p.mt-5 En la tabla 2 se presenta una comparación entre las alianzas aéreas, para destacar sus principales características:
    .titulo-sexto.color-acento-contenido.mt-4
      p Tabla 2
    .row
      .h4.mt-4.mb-0.cuadro-secundario Star Alliance
    .row.mt-3
      .col-4.col-lg-3.offset-4.offset-lg-0.bg-amarillo-5.rounded-der-top.center-x-y
        figure.mt-5
          img(src="@/assets/template/tema-1-21.png", alt="Texto que describa la imagen").w-75.margin-0-auto
      .col-12.col-lg-9
        TabsC.color-primario.mb-5
          .py-3.py-md-4(titulo="Características")
            .row.px-4
              figure
                img(src="@/assets/template/tema-1-22.png", alt="Texto que describa la imagen")
              .col-
                ul.lista-ul--color.mt-4.px-4
                  li 
                    i.fas.fa-brain
                    | Fundada en 1997 por 5 aerolíneas.
                  li 
                    i.fas.fa-brain
                    | Tiene como slogan “la red de aerolíneas para la tierra”.
                  li 
                    i.fas.fa-brain
                    | Es la red más importante de alianza global.
                  li  
                    i.fas.fa-brain
                    | Tiene la mayor cantidad de miembros activos, 26 actualmente. 
                  li 
                    i.fas.fa-brain
                    | Facturación prioritaria del equipaje al momento de hacer check in para el vuelo.
                  li 
                    i.fas.fa-brain
                    | Manejo preferencial de equipaje.
                  li 
                    i.fas.fa-brain
                    | Acceso a salas VIP
                  li 
                    i.fas.fa-brain
                    | Embarque prioritario.
                  li 
                    i.fas.fa-brain
                    | Equipaje adicional permitido.
                  li 
                    i.fas.fa-brain
                    | Prioridad en listas de espera
          .py-3.py-md-4(titulo="Miembros")
            .row
              figure
                img(src="@/assets/template/tema-1-23.png", alt="Texto que describa la imagen")
              ol.lista-ol--cuadro.mt-4.px-4.secundario
                li 
                  .lista-ol--cuadro__vineta
                    span 1
                  | Aegean
                li 
                  .lista-ol--cuadro__vineta
                    span 2
                  | Air Canada
                li 
                  .lista-ol--cuadro__vineta
                    span 3
                  | Air China
                li 
                  .lista-ol--cuadro__vineta
                    span 4
                  | Air India
                li 
                  .lista-ol--cuadro__vineta
                    span 5
                  | Air New Zealand
                li 
                  .lista-ol--cuadro__vineta
                    span 6
                  | Ana
                li 
                  .lista-ol--cuadro__vineta
                    span 7
                  | Asiana Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 8
                  | Austrian
                li 
                  .lista-ol--cuadro__vineta
                    span 9
                  | Avianca
                li 
                  .lista-ol--cuadro__vineta
                    span 10
                  | Brussels Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 11
                  | Copa Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 12
                  | Croatia Airlines 
                li 
                  .lista-ol--cuadro__vineta
                    span 13
                  | Egypt Air
                li 
                  .lista-ol--cuadro__vineta
                    span 14
                  | Ethiopian Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 15
                  | Eva Air
                li 
                  .lista-ol--cuadro__vineta
                    span 16
                  | LOT Polish Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 17
                  | Lufthansa
                li 
                  .lista-ol--cuadro__vineta
                    span 18
                  | SAS
                li 
                  .lista-ol--cuadro__vineta
                    span 19
                  | Shenzhen Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 20
                  | Singapore Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 21
                  | South African Airways
                li 
                  .lista-ol--cuadro__vineta
                    span 22
                  | Swiss
                li 
                  .lista-ol--cuadro__vineta
                    span 23
                  | TAP Air Portugal
                li 
                  .lista-ol--cuadro__vineta
                    span 24
                  | Thai
                li 
                  .lista-ol--cuadro__vineta
                    span 25
                  | Turkish Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 26
                  | Uinted    
    .row.mt-5
      .h4.mt-4.mb-0.cuadro-acento-contenido One World               
    .row.mt-3
      .col-4.col-lg-3.offset-4.offset-lg-0.bg-acento-botones-5.rounded-der-top.center-x-y
        figure.mt-5
          img(src="@/assets/template/tema-1-24.png", alt="Texto que describa la imagen").w-75.margin-0-auto
      .col-12.col-lg-9
        TabsC.color-acento-contenido.mb-5
          .py-3.py-md-4(titulo="Características")
            .row.px-4
              figure
                img(src="@/assets/template/tema-1-26.png", alt="Texto que describa la imagen")
              .col
                ul.lista-ul--color.mt-4.px-4
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Fundada en 1999 por 5 aerolíneas.                    
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Tiene como premisa “tratar a todos los pasajeros de One World como si fueran nuestros propios pasajeros y responder a sus preguntas en el primer punto de contacto”. 
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | 15 aerolíneas miembro de la red.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Vuelos diseñados para personas no acostumbradas a volar frecuentemente.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Política de endoso sujeta a restricciones.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | No se reconfirman los vuelos.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Tarjeta de embarque hasta el destino final entre la red.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Acceso a una franquicia de equipaje, se aplica la política menos restrictiva del tiquete.
                  li 
                    i.fas.fa-bug.color-acento-botones
                    | Realizar cambios voluntarios o involuntarios en el tiquete, el cual puede ser aceptado por una compañía perteneciente a la red.
          .py-3.py-md-4(titulo="Miembros")
            .row
              figure
                img(src="@/assets/template/tema-1-27.png", alt="Texto que describa la imagen")
              ol.lista-ol--cuadro.mt-4.px-4
                li 
                  .lista-ol--cuadro__vineta
                    span 1
                  | Alaska
                li 
                  .lista-ol--cuadro__vineta
                    span 2
                  | American Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 3
                  | British Airways
                li 
                  .lista-ol--cuadro__vineta
                    span 4
                  | Cathay Pacific
                li 
                  .lista-ol--cuadro__vineta
                    span 5
                  | FinnAir
                li 
                  .lista-ol--cuadro__vineta
                    span 6
                  | Iberia
                li 
                  .lista-ol--cuadro__vineta
                    span 7
                  | Japan Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 8
                  | Malaysia
                li 
                  .lista-ol--cuadro__vineta
                    span 9
                  | Qantas
                li 
                  .lista-ol--cuadro__vineta
                    span 10
                  | Qatar
                li 
                  .lista-ol--cuadro__vineta
                    span 11
                  | Royal Jordanian
                li 
                  .lista-ol--cuadro__vineta
                    span 12
                  | S7 Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 13
                  | SriLanka Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 14
                  | Fiji Airways
                li 
                  .lista-ol--cuadro__vineta
                    span 15
                  | Royal Air Maroc
    
    .row.mt-5
      .h4.mt-4.mb-0.cuadro-amarillo Sky Team               
    .row.mt-3
      .col-4.col-lg-3.offset-4.offset-lg-0.bg-secundario-5.rounded-der-top.center-x-y
        figure.mt-5
          img(src="@/assets/template/tema-1-28.png", alt="Texto que describa la imagen").w-75.margin-0-auto
      .col-12.col-lg-9
        TabsC.color-primario.mb-5
          .py-3.py-md-4(titulo="Características")
            .row.px-4
              figure
                img(src="@/assets/template/tema-1-29.png", alt="Texto que describa la imagen")
              .col
                ul.lista-ul--color.mt-4.px-4
                  li 
                    i.fas.fa-brain
                    | Fundada en el 2000 por 4 aerolíneas.
                  li 
                    i.fas.fa-brain
                    | Es la red con mayor presencia en China y Taiwan.
                  li 
                    i.fas.fa-brain
                    | 19 aerolíneas miembro de la red.
                  li 
                    i.fas.fa-brain
                    | Check in en mostradores preferenciales.
                  li 
                    i.fas.fa-brain
                    | Ascensos de categoría en vuelos.
                  li 
                    i.fas.fa-brain
                    | Abordaje preferencial.
                  li 
                    i.fas.fa-brain
                    | Mayor capacidad de equipaje.
          .py-3.py-md-4(titulo="Miembros")
            .row
              figure
                img(src="@/assets/template/tema-1-31.png", alt="Texto que describa la imagen")
              ol.lista-ol--cuadro.mt-4.px-4.secundario
                li 
                  .lista-ol--cuadro__vineta
                    span 1
                  | Aeroflot
                li 
                  .lista-ol--cuadro__vineta
                    span 2
                  | Aerolíneas Argentinas
                li 
                  .lista-ol--cuadro__vineta
                    span 3
                  | AeroMexico
                li 
                  .lista-ol--cuadro__vineta
                    span 4
                  | Air Europa
                li 
                  .lista-ol--cuadro__vineta
                    span 5
                  | Air France
                li 
                  .lista-ol--cuadro__vineta
                    span 6
                  | AlItalia
                li 
                  .lista-ol--cuadro__vineta
                    span 7
                  | China Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 8
                  | China Eastern
                li 
                  .lista-ol--cuadro__vineta
                    span 9
                  | Czech Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 10
                  | Delta
                li 
                  .lista-ol--cuadro__vineta
                    span 11
                  | Garuda Indonesia
                li 
                  .lista-ol--cuadro__vineta
                    span 12
                  | Kenya Airways
                li 
                  .lista-ol--cuadro__vineta
                    span 13
                  | KLM
                li 
                  .lista-ol--cuadro__vineta
                    span 14
                  | Korean Air
                li 
                  .lista-ol--cuadro__vineta
                    span 15
                  | MEA
                li 
                  .lista-ol--cuadro__vineta
                    span 16
                  | Saudia
                li 
                  .lista-ol--cuadro__vineta
                    span 17
                  | Tarom
                li 
                  .lista-ol--cuadro__vineta
                    span 18
                  | Vietnam Airlines
                li 
                  .lista-ol--cuadro__vineta
                    span 19
                  | Xiamen Air
    .titulo-segundo.mt-5
      #t_1_4.h4 1.4  Sistemas de distribución
    figure
      img(src="@/assets/template/tema-1-32.png", alt="Texto que describa la imagen")
    p.mt-5 En la creación de un tiquete de transporte aéreo, es necesario contar con un sistema de distribución que permita el acceso al inventario de vuelos que tiene la compañía, rutas, horarios, frecuencias, equipo que opera la ruta, cotización de itinerarios etc., inicialmente se llamaron CRS Computer Reservation System o en español sistema de reservas por computadora, estaban disponibles solo para aerolíneas, posteriormente por exigencias del mercado se extendió hasta cubrir el campo de las agencias de viajes, con el avance de la tecnología llegaron los denominados GDS (Global Distribution System/ Sistemas de Distribución Global), que permitió tener acceso a información más amplia vía internet tanto para la empresa como para los usuarios.
    p.mt-5 En la siguiente línea de tiempo se presenta la evolución de los sistemas de distribución: 
    .row.mt-5
      .col-12.px-5.py-4
        LineaTiempoC.color-acento-contenido(text-small)
          .row(titulo="1960")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-33.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small #[strong Sabre] fue el primer GSD en aparecer en el mercado, se logra procesar 84.000 llamadas telefónicas, inicialmente se creó para reservas telefónicas en la compañía.

          .row(titulo="1976")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-34.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small #[strong Sabre] da inicio a la primera pantalla dispuesta en una agencia de viajes, considerándose como la primera red de telecomunicaciones en el mercado
          .row(titulo="1980")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-35.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small Con la llegada de internet, Sabre ofrece bajo el nombre de Eaasy Sabre reservas aéreas a través de CompuServe y Genie.
          .row(titulo="1987")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-36.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small #[strong Amadeus,] fue creado en 1987 por. Air France, Lufthansa, Iberia, Scandinavian Airlines e IBM; gracias al uso de la tecnología que le ha dado un enfoque innovador a la experiencia de viaje, es el GDS líder en el mercado.
          .row(titulo="1993")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-37.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small  En 1993 el GDS #[strong Galileo] basado en la Red Apollo, sirve a usuarios en Europa, Sudamérica, Asia y África. Pero no llega con mucha fuerza para competir con Sabre y Amadeus.
          .row(titulo="Actualidad")
            .col-1.col-lg-2
              figure
                img(src="@/assets/template/tema-1-38.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .col-9.col-lg-10.center-x-y
              p.text-small Además de los GDS mencionados, se cuenta con #[strong Travelport], cuyo enfoque está basado en el mercado de las agencias de viaje..    
    .row.mt-5
      .col-12.col-lg-8
        p De acuerdo con González (2017), con el pasar de los años y a fin de ofrecer un servicio completo, se amplía los servicios del Sistema de Distribución Globalizada (GDS), logrando extender su funcionalidad en otras áreas relacionadas con el turismo, por ejemplo:
        ul.lista-ul.mt-4
          li 
            i.fas.fa-angle-right
            | Reservación en servicios de hospedaje.
          li.mt-2
            i.fas.fa-angle-right
            | Restaurantes.
          li.mt-2
            i.fas.fa-angle-right
            | Alquiler de vehículos.
          li.mt-2
            i.fas.fa-angle-right
            | Reservación de espacios en trenes, barcos.
          li.mt-2
            i.fas.fa-angle-right
            | Reservas para atractivos turísticos. 
          li.mt-2
            i.fas.fa-angle-right
            | Validación de pagos con tarjetas de crédito. 
          li.mt-2
            i.fas.fa-angle-right
            | Acceso a un sistema de información general, desde cualquier sitio conectado a internet.
          li.mt-2
            i.fas.fa-angle-right
            | Reservaciones automáticas.
          li.mt-2
            i.fas.fa-angle-right
            | Creación de un Passanger Name Record (PNR), registro del nombre de pasajero, es decir, una reserva de vuelo. 
      .col-6.col-lg-4.offset-4.offset-lg-0.align-self-center
        figure
          img(src="@/assets/template/tema-1-39.svg", alt="Texto que describa la imagen")
    p.mt-5 La mayoría de los sistemas de distribución ofrecen la posibilidad de varias modalidades de trabajo, una es la pantalla de trabajo gráfico, donde se solicita la información por medio de casillas para diligenciar, y la más común es la pantalla críptica, donde por medio de comandos y códigos se le indica al sistema que tarea debe realizar.
    p.mt-3 Para manejar la pantalla críptica de los sistemas de distribución es importante, entender conceptos como:
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .cajon.color-acento-botones.p-4.mb-4.bg-primario-5
          .h4.px-4.pt-3 Codificar
          p.mb-0.px-4.py-3 Solicitarle al sistema que indique cuál es el código de determinada información ingresada, si es de país, ciudad o aeropuerto.
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .cajon.color-acento-botones.p-4.mb-4.bg-primario-2
          .h4.px-4.pt-3 Decodificar
          p.mb-0.px-4.py-3 Indicarle al sistema que indique a qué corresponde ese código que se está ingresando, si es de ciudad, país o aeropuerto. 
    p.mt-5 En la tabla 3 Se presenta un ejemplo de codificación y decodificación en el GDS Amadeus:
    .titulo-sexto.color-acento-contenido.mt-5
      p Tabla 3
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .tabla-a.color-secundario.mb-5 
          table
            thead
              tr.bg-secundario
                th OPCIONES
                th CODIFICAR
                th EJEMPLO
            tbody.text-center.bg-amarillo-claro-mas
              tr
                td Países
                td DC + (Nombre país)
                td DCCOLOMBIA
              tr
                td Ciudades
                td 	DAN + (Nombre Ciudad)
                td DANBOGOTA
              tr
                td Aeropuertos
                td DAN + (Nombre Aeropuerto)
                td DANBOG
              tr
                td Aerolíneas
                td DNA + (Nombre Aerolínea)
                td DNAAVIANCA
              tr
                td Aeronaves
                td DNE + (Nombre de Aeronave)
                td DNEAIRBUS
    .row.mt-3
      .col-10.col-lg-8.offset-1.offset-lg-2
        .tabla-a.color-secundario.mb-5 
          table
            thead
              tr.bg-secundario
                th OPCIONES
                th CODIFICAR
                th EJEMPLO
            tbody.text-center.bg-amarillo-claro-mas
              tr
                td Países
                td DC + (Código de País)
                td DCCO
              tr
                td Ciudades
                td DAC + (Código de Ciudad)
                td DANBOG
              tr
                td Aeropuertos
                td DAC + (Código de Aeropuerto)
                td DANBOG
              tr
                td Aerolíneas
                td DNA + (Código de Aerolínea)
                td DNAAV
              tr
                td Aeronaves
                td DNE + (Nombre de Aeronave)
                td DNE320
    p.mt-5 En la tabla 4 se presenta un ejemplo de codificación y decodificación en el GDS Sabre:
    .titulo-sexto.color-acento-contenido.mt-5
      p Tabla 4
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .tabla-a.color-acento-botones.mb-5 
          table
            thead
              tr.bg-acento-botones.text-white
                th OPCIONES
                th CODIFICAR
                th EJEMPLO
            tbody.text-center.bg-morado-claro
              tr
                td Países
                td HCCC+ (nombre país)
                td HCCC/COLOMBIA
              tr
                td Ciudades
                td W/-CC + (nombre ciudad)
                td W/-CCBOGOTA
              tr
                td Aeropuertos
                td W/-CC + (nombre aeropuerto)
                td W/-CCBOG
              tr
                td Aerolíneas
                td W/-AL + (nombre aerolínea)
                td W/-ALAVIANCA
              tr
                td Aeronaves
                td W/EQ- + (nombre de aeronave)
                td W/EQ-AIRBUS
    .row.mt-4
      .col-10.col-lg-8.offset-1.offset-lg-2
        .tabla-a.color-acento-botones.mb-5 
          table
            thead
              tr.bg-acento-botones.text-white
                th OPCIONES
                th CODIFICAR
                th EJEMPLO
            tbody.text-center.bg-morado-claro
              tr
                td Países
                td HCCC+ (código país)
                td HCCC+ (código país)
              tr
                td Ciudades
                td W/* + (código ciudad)
                td W/*CCBOG
              tr
                td Aeropuertos
                td W/* + (nombre aeropuerto)
                td W/*BOG
              tr
                td Aerolíneas
                td W*/ + (nombre aerolínea)
                td W*/ALAV
              tr
                td Aeronaves
                td W/EQ* + (nombre de aeronave)
                td W/EQ*320           




</template>

<script>
import Muestras from '../components/Muestras' // borrar una vez el componente "Muestras" no se necesite
export default {
  name: 'Tema1',
  components: {
    Muestras, // borrar una vez el componente "Muestras" no se necesite
  },
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>
<style lang="sass" scoped></style>
