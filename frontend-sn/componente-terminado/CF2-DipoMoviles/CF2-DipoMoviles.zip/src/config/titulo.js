module.exports = 'Diseño y construcción de Frontend'
