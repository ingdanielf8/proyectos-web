module.exports = 'Entorno organizacional y ambiental'
