<template lang="pug">
div
  table
    tbody
      tr
        td.p-0
          figure
            img(src="@/assets/template/tema-1-1.png" alt="Texto que describa la imagen")
        td.p-0 
          figure
            img(src="@/assets/template/tema-1-2.png" alt="Texto que describa la imagen")
      tr
        td.text-center.py-4 Requieren intervención de los usuarios o las personas.
        td.text-center No requieren total intervención humana, usan un software especializado para tal fin. 
       



</template>

<script>
export default {
  name: 'Tabla1',
  data: () => ({}),
}
</script>

<style lang="sass" scoped></style>
