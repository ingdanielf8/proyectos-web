module.exports = 'Brief comunicación'
