module.exports = 'Arquitectura de aplicaciones móviles nativas.'
