<template lang="pug">
.curso-main-container.pb-3(style="overflow: hidden")
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5(style="overflow: hidden")
    
    .titulo-principal
      .titulo-principal__numero
        span 2
      h1 Lodging // Alojamiento
    .row.mt-5.position-relative.pb-5
      .col-8.align-self-center.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 0%; padding-top: 9%; padding-bottom:9%")
        p En la actualidad existen muchas compañías que con solo mirar su imagen o logotipo se pueden identificar y muchas de ellas son reconocidas en los mercados nacionales e internacionales por llamativa o singular que puede llegar a hacer su imagen o logotipo corporativo. En este apartado estudiaremos lo relacionado a la imagen corporativa que debe implementar una unidad productiva. 
    
      .col-6.offset-6
        figure
          img(src="@/assets/template/tema-2-1.png", alt="Texto que describa la imagen")
    
    
    



    .titulo-segundo.mt-5.pt-5
      #t_2_1.h2 2.1  	Imagen corporativa   
    .row.mt-5.position-relative
      .col-8.align-self-center.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 33%; padding-top: 6%; padding-bottom:6%; top:5%")
        p Se concibe como la forma en que el público percibe la marca de la unidad productiva, sus productos o servicios.
        p.mt-3 La imagen corporativa comprende sensaciones, ideas, juicios y prejuicios, aspectos que pueden ser muy beneficiosos o no y que están asociadas a las creencias y actitudes que perciben las personas frente a la unidad productiva o marca.
      
      .col-6
        figure
          img(src="@/assets/template/tema-2-2.png", alt="Texto que describa la imagen")
      .row.mt-4
        .col-10.offset-1.mt-5
          .titulo-sexto.color-acento-contenido
            h5.text-small Figura 2
            p.text-small.italic Imagen corporativa
          figure.mt-3
            img(src="@/assets/template/tema-2-3.png", alt="Texto que describa la imagen")
    p.mt-4 La siguiente infografía animada, muestra cuales son los beneficios: 
    figure.mt-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/2L91WMqw96A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    .row.mt-5
      .col-10
        p Todos estos beneficios además de atraer clientes, también genera la confianza de nuevos talentos e inversores.
        p.mt-3 En la actualidad encontramos muchas imágenes corporativas muy famosas en el mundo empresarial demarcas registradas, entre estas vemos la de Apple con su logo de manzana, Nike con su logo modo tic curvo y Coca-Cola con su nombre y color representativo. Sus logos y marcas son fáciles de reconocer, logrando generar una identidad y afinidad con los consumidores.
      .col-2.align-self-center
        figure
          img(src="@/assets/template/tema-2-4.svg", alt="Texto que describa la imagen").w-75.margin-0-auto.floating

    .row.mt-5
      .col-4.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in
            figure
              img(src="@/assets/template/tema-2-5.png", alt="Texto que describa la imagen").w-50.margin-0-auto
            .h4.mt-4 Apple
            .row.mt-4
              .col-lg-12
                a.anexo.mb-4.mb-lg-0(href="https://www.apple.com/co/" target="_blank")
                  .anexo__icono.color-primario
                    img(src="@/assets/template/icono-link.svg")
                  .anexo__texto
                    p.text-small Enlace web. https://www.apple.com/co/
      
      .col-4.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in
            figure
              img(src="@/assets/template/tema-2-6.png", alt="Texto que describa la imagen").w-50.margin-0-auto
            .h4.mt-4 Nike
            .row.mt-4
              .col-lg-12
                a.anexo.mb-4.mb-lg-0(href="https://www.nike.com/us/es/" target="_blank")
                  .anexo__icono.color-primario
                    img(src="@/assets/template/icono-link.svg")
                  .anexo__texto
                    p.text-small Enlace web. https://www.nike.com/us/es/
      .col-4.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in
            figure
              img(src="@/assets/template/tema-2-7.png", alt="Texto que describa la imagen").w-50.margin-0-auto
            .h4.mt-4 Coca Cola
            .row.mt-4
              .col-lg-12
                a.anexo.mb-4.mb-lg-0(href="https://www.avatrade.es/cfd-trading/acciones/acciones-coca-cola" target="_blank")
                  .anexo__icono.color-primario
                    img(src="@/assets/template/icono-link.svg")
                  .anexo__texto
                    p.text-small Enlace web. https://www.avatrade.es/cfd-trading/acciones/acciones-coca-cola
    .row.mt-5
      .col-2.align-self-center
        figure
          img(src="@/assets/template/tema-2-8.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.floating
      .col-10.align-self-center
        p Es por esta razón que la imagen corporativa es tan importante, pues su marca debe conseguir que el cliente, simplemente con ver su logo o detectar el color logre identificar su empresa. Relacionando rápidamente la empresa y los productos con determinados valores, de calidad, deseo de compra y orgullo por portarlos.
    separador.mt-4
    .titulo-segundo.mt-5
      #t_2_2.h2 2.2  	Características del plan de negocios
    .row.mt-5
      .col-12.rounded-20.bg-amarillo-claro.p-5
        .row.zoom-in
          .col-4
            p Toda imagen corporativa debe ser unánime en sus recursos visuales, transmitiendo así de forma efectiva el mensaje que quiere dar a conocer la unidad productiva. Entre las características de la imagen corporativa se encuentran:
            ul.lista-ul.mt-3
              li 
                i.fas.fa-angle-right.naranja
                | Debe existir una coherencia entre la filosofía de la empresa y la imagen, bajo unos mismos criterios.
              li 
                i.fas.fa-angle-right.naranja
                | Debe ser reflejo del concepto y propuesta de valor.
              li 
                i.fas.fa-angle-right.naranja
                | Debe tener en cuenta el comportamiento ético y moral.
              li 
                i.fas.fa-angle-right.naranja
                | Debe permanecer en la mente del público y ser de fácil recordación.
              li 
                i.fas.fa-angle-right.naranja
                | Dependerá en parte de lo que comunica la empresa.
              li 
                i.fas.fa-angle-right.naranja
                | Incide en la diferenciación de la empresa.
          .col-8
            figure
              img(src="@/assets/template/tema-2-9.svg", alt="Texto que describa la imagen")
    separador.mt-4

    .titulo-segundo.mt-5
      #t_2_3.h2 2.3  	Elementos de la imagen corporativa 
    .row.mt-5
      .col-9
        p Partiendo de la importancia que tiene una imagen corporativa, es preciso mencionar que para su creación y diseño es necesario antes realizar un análisis de la unidad productiva, del producto y el sector en donde este opera. Este análisis puede realizarse mediante un estudio FODA donde se valoren las debilidades, fortalezas, amenazas y oportunidades. Para esto es importante tener clara la misión y valores de la empresa como el público objetivo al que se va apostar en la unidad productiva.
        p.mt-3 Toda unidad productiva en su estructuración debe contar con una serie de elementos que fortalezcan la imagen corporativa y a su vez, les permita posicionarse en el mercado. Entre estos elementos encontramos:
      .col-3
        figure
          img(src="@/assets/template/tema-2-10.svg", alt="Texto que describa la imagen").floating    
      .col-10.offset-1.mt-5
        .titulo-sexto.color-acento-contenido
          h5.text-small Figura 2
          p.text-small.italic Imagen corporativa
    .row.justify-content-center(data-aos="fade-down").mt-4
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-11.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text Nombre de la Empresa
                p.mt-3.small-text Ofrecer una primera impresión ante el público.
                
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-12.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text El logotipo
                p.mt-3.small-text Debe ser fácil de interpretar, de identificar y de recordar.
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-13.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text El eslogan
                p.mt-3.small-text Sintetiza la filosofía de la empresa y la condensa en una frase que debe ser llamativa e impactante.
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-14.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-5.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text La identidad gráfica
                p.mt-3.small-text Está compuesta por la tipografía y los colores de la marca. Características de la letra que se va a emplear (fuente, tamaño, etc.).
    .row.justify-content-center(data-aos="fade-down").mt-3
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-15.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text El sitio web
                p.mt-3.small-text Ofrecer una primera impresión ante el público.
                
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-16.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text El material corporativo
                p.mt-3.small-text Son elementos como las tarjetas de visita, carpetas, mostradores, displays, folletos, catálogos, posters, regalos promocionales y material para ferias, entre otros. Deben mantener coherencia.  
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-17.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-5.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text La atmósfera
                p.mt-3.small-text Las instalaciones de la empresa, físicas o virtuales, deben generar una atmósfera agradable a la vista, el oído, el olfato y el tacto. De ser posible, también al gusto.
      .col-lg-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.py-5
            figure
              img(src="@/assets/template/tema-2-18.svg", alt="Texto que describa la imagen").w-60.margin-0-auto.mb-3.px-4
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text La historia y la reputación
                p.mt-3.small-text Se construyen principalmente con la calidad de los productos y servicios. Es importante la buena atención, responsabilidad y puntualidad.
    figcaption.mt-3 Referencia Nota. SENA (2021)
    
    .titulo-segundo.mt-5
      #t_2_4.h2 2.4  	Mercado    
    .row.mt-5.position-relative
      .col-8.align-self-center.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 0%; padding-top: 5%; padding-bottom:5%")
        p El mercado es un escenario importante para toda unidad productiva, pues es en este donde se comercializan sus productos y servicios. Se define mercado al conjunto de actividades realizadas libremente por los agentes económicos sin intervención del estado, en el cual intervienen consumidores y productores, la interacción entre estos agentes al momento de intercambiar sus productos o servicios, permite establecer el precio de las mercancías, bienes o servicios. En este intercambio se puede indicar que estas conductas obedecen a una serie de necesidades y características propias del territorio y el contexto del mercado. 

      .col-6.offset-6
        figure
          img(src="@/assets/template/tema-2-19.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-8.offset-2
        .row
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row
                .col-3
                  figure
                    img(src="@/assets/template/tema-2-20.svg", alt="Texto que describa la imagen").w-75.margin-0-auto.floating
                .col-9.align-self-center             
                  p.text-small Por esta razón es importante tener una imagen corporativa fuerte que permita hacer una diferenciación de la marca con la competencia. Esto llevaría a un posicionamiento más preciso y se convierte en una ventaja competitiva que a largo plazo reduciría de manera significativa los gastos en publicidad. 
    p.mt-5 Al momento de estudiar el mercado, es importante conocer los factores que interactúan en este y hacen que la dinámica comercial se desarrolle entorno a la comercialización de productos y servicios. Aquí encontramos la demanda y oferta que viene determinada por: 
    .row.mt-5
      .col-6.position-relative.px-0
        figure.px-2
          img(src="@/assets/template/tema-2-21.png", alt="Texto que describa la imagen")
        .row.image-cover.mx-0
          figure.px-2
            img(src="@/assets/template/tema-2-21-1.svg", alt="Texto que describa la imagen")
          .col-12(style="margin-top: -25%")
            .h4.text-center Demanda
            p.text-center.mt-3 La cantidad de producto que los compradores están dispuestos a adquirir a un determinado precio.

      .col-6.position-relative.px-0
        figure.px-2
          img(src="@/assets/template/tema-2-99.png", alt="Texto que describa la imagen")
        .row.image-cover.mx-0
          figure.px-2
            img(src="@/assets/template/tema-2-21-1.svg", alt="Texto que describa la imagen")
          .col-12(style="margin-top: -25%")
            .h4.text-center Oferta
            p.text-center.mt-3.px-2 La cantidad de producto que los vendedores están dispuestos a ofrecer a un determinado precio.
    separador.mt-3 
    .titulo-segundo.mt-5
      #t_2_5.h2 2.5 	Objetivo    
    p.mt-5 Como se ha venido observando en el componente formativo, una imagen corporativa es de suma importancia para la unidad productiva. Esta imagen tiene ciertos elementos que se deben tener en cuenta para su creación y debe incorporar características propias y esenciales de la empresa. en razón de lo mencionado se puede describir el objetivo de la imagen corporativa como: 
    .row.mt-5
      .col-8.offset-2
        .row
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row
                .bloque-texto-b.color-secundario.px-4
                  .bloque-texto-b__texto
                    i.fas.fa-quote-left
                    .h4.mb-0 Mínguez (2000), determina que el objetivo de la Imagen Corporativa es mantener la presencia de la empresa en la mente del público, conservar o aumentar las ventas, darle cierto prestigio a la empresa, reducir costos de publicidad y fomentar la publicidad espontánea.
                    i.fas.fa-quote-right 
    .row.mt-5
      .col-12.px-5
        figure
          img(src="@/assets/template/tema-2-22.png", alt="Texto que describa la imagen")
    p.mt-5 En otras palabras, las unidades productivas buscan que sus clientes se sientan reflejados con sus valores, que incremente su fidelización y que ellos sean los mejores vendedores de la marca a través de sus opiniones y recomendaciones. 
    separador.mt-3
    .titulo-segundo.mt-5
      #t_2_6.h2 2.6 	Sensaciones
    p.mt-5 La imagen corporativa juega un papel principal en la transmisión de sentimientos y emociones a los clientes, se  cómo:
    figure.mt-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/2L91WMqw96A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    ImagenInfografica.color-primario.mt-4.position-relative
      template(v-slot:imagen)
        .row.position-absolute(style="top:84.5%; left:27.5%")
          .h4.font-20 1
        .row.position-absolute(style="top:35.3%; left:40.5%")
          .h4.font-20 2
        .row.position-absolute(style="top:65.5%; left:58.5%")
          .h4.font-20 3
        figure
          img(src='@/assets/template/tema-2-infograf.png', alt='Texto que describa la imagen')

      .tarjeta(x="28%" y="86%").punto1
        .row.borde-azul-3.rounded-15.bg-blanco
          .col-1.px-0.mx-0.bg-a.bg-azul-claro
            .h4.text-center.pt-3.font-20 1
          .col-11
            p.pt-4.pb-5.px-3 El diseño de una buena imagen logra generar identidad, distinción y aportan valor a la marca. 
            
      .tarjeta(x="41%" y="37%")
        .row.borde-azul-3.rounded-15.bg-blanco
          .col-1.px-0.mx-0.bg-a.bg-azul-claro
            .h4.text-center.pt-3.font-20 2
          .col-11
            p.pt-4.pb-5.px-3 Los consumidores desarrollan una serie de estímulos y sensaciones de tipo afectivo en relación a las marcas. 
      .tarjeta(x="59%" y="67%")
        .row.borde-azul-3.rounded-15.bg-blanco
          .col-1.px-0.mx-0.bg-a.bg-azul-claro
            .h4.text-center.pt-3.font-20 3
          .col-11
            p.pt-4.pb-5.px-3 La decisión del cliente al momento de elegir entre el producto de la empresa y otro de la competencia, se basará en el producto que le generó una percepción positiva. 

    
    
    
    
    
    
    .titulo-segundo.mt-5
      #t_2_7.h2 2.7  	Prejuicios y experiencias 
    .row.mt-5
      .col-4.align-self-center
        figure.px-4
          img(src="@/assets/template/tema-2-23.svg", alt="Texto que describa la imagen").floating
      .col-8.rounded-20.bg-amarillo-claro.p-5
        p En el contexto actual solo se necesitan unos segundos para hacerse una imagen mental de otra persona y establecer un prejuicio (etiqueta). Las marcas y las empresas también sufren de prejuicios. Es por esta razón que se debe cuidar la imagen corporativa en un mercado tan competitivo donde las empresas cada vez más se cuidan de ser víctimas de los prejuicios.
        .row.mt-4
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row
                p El objetivo de toda unidad productiva es evitar que se tenga una percepción negativa de la imagen corporativa a partir del logo, nombre, comunicado, etc. y que llegue a ser sinónimo de percepción negativa sobre la calidad de los productos y servicios,  es por esta razón tan importante mantener una buena imagen y percepción de la unidad productiva en los diferentes recursos corporativos (web, tarjetas, redes, etc.). 
        p Las experiencias del cliente al momento de adquirir un producto o servicio de la unidad productiva son fundamentales para que vuelva a comprar y gran parte de este impacto tiene que ver con la imagen corporativa.
        p.mt-3 Es por esta razón que la imagen debe generar en el consumidor esa satisfacción y confianza para que vuelva a comprar los productos o servicios.
    
    
    

    
    
        

</template>

<script>
export default {
  name: 'Tema2',
  data: () => ({
    // variables de vue
    mostrarIndicador: true,
    modalP: false,
    modalH: false,
    modalA1: false,
    modalV: false,
    indicadorTarjetaFlip: true,
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
