<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 3
      h1 Marketing y publicidad de la unidad productiva
    figure
      img(src="@/assets/template/tema-3-1.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.col-lg-9
        p Día a día el mundo se encuentra envuelto en intercambios comerciales cada vez más amplios y con mayores oferentes o competidores y cada unidad productiva debe establecer en sus áreas de trabajo el marketing como foco principal para identificar oportunidades. 
        .row.mt-3 
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row 
                p Definimos entonces el marketing como el conjunto de técnicas destinadas a conocer el entorno de la empresa y poder identificar las oportunidades que se ofrecen. 
        p.mt-3 A su vez, establece las estrategias que sirven para posicionar un producto o una institución en un mercado determinado. Con el objetivo de satisfacer las necesidades y deseos de las personas mediante procesos de intercambio. 
      .col-3.d-none.d-lg-block
        figure
          img(src="@/assets/template/tema-3-2.svg", alt="Texto que describa la imagen").floating
    .titulo-segundo.mt-5
      #t_3_1.h2 3.1  	Variables de mercadeo
    p.mt-5 La estructura del mercado está determinada por aspectos del entorno general y por agentes que interactúan internamente, tales como: 
    .row.justify-content-center(data-aos="fade-down").mt-5
      .col-10.col-md-6.col-lg-4.col-xl-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.px-0
            figure
              img(src="@/assets/template/tema-3-3.png", alt="Texto que describa la imagen")
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text Fabricantes de bienes y prestadores de servicios: 
                p.mt-3.small-text Pueden influenciar en el mercado dependiendo de su tamaño, de ahí dependerá su cuota del mercado
                
      .col-10.col-md-6.col-lg-4.col-xl-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.px-0
            figure
              img(src="@/assets/template/tema-3-4.png", alt="Texto que describa la imagen")
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text.pt-2 Intermediarios: 
                p.mt-3.small-text Encargados de acercar los productos de las empresas a los consumidores y pueden ser influenciadores del mercado. Entre estos encontramos: las televentas, ventas por internet o redes sociales, etc.
      .col-10.col-md-6.col-lg-4.col-xl-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.px-0
            figure
              img(src="@/assets/template/tema-3-5.png", alt="Texto que describa la imagen")
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text.pt-2 Prescriptores: 
                p.mt-3.small-text No compran ni venden, pero influyen en la compra (Ej: médicos al formular medicamentos).
      .col-10.col-md-6.col-lg-4.col-xl-3
        .row.px-2.pt-2.h-100
          .col-12.m-0.nav-holder2.align-items-center.rounded-15.box-shadow.px-0
            figure
              img(src="@/assets/template/tema-3-6.png", alt="Texto que describa la imagen")
            .text.p-lg-3.p-4
              .row.text-center.px-1.pt-1
                .h4.small-text.pt-2 Compradores:
                p.mt-3.small-text Influyen en el mercado, por sus características y modo de realizar las compras.
    separador.mt-3
    
    .titulo-segundo.mt-5
      #t_3_2.h2 3.2  	Análisis de mercado
    .row.mt-5.position-relative
      .col-10.offset-1.d-block.d-xl-none.bg-acento-botones.rounded-20.px-5.py-4
        p El mercado se puede entender como el lugar donde se realizan intercambios entre un conjunto de compradores (demandantes o consumidores) y los vendedores (oferentes o productores). A raíz de esto se hace importante identificar quiénes son cada uno de estos agentes que interactúan en el mercado y poder analizar su comportamiento, ya sea de compra o producción. Para lograr averiguar esto, se necesita de un estudio del mercado para identificar los compradores potenciales ante un producto o servicio determinado, con el fin de plantear la estrategia comercial más adecuada.
        p.mt-3 En un mercado se encuentran los siguientes elementos básicos que lo integran:
      .col-8.align-self-center.d-none.d-xl-block.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 33%; padding-top: 5%; padding-bottom:5%; top:11%")
        p El mercado se puede entender como el lugar donde se realizan intercambios entre un conjunto de compradores (demandantes o consumidores) y los vendedores (oferentes o productores). A raíz de esto se hace importante identificar quiénes son cada uno de estos agentes que interactúan en el mercado y poder analizar su comportamiento, ya sea de compra o producción. Para lograr averiguar esto, se necesita de un estudio del mercado para identificar los compradores potenciales ante un producto o servicio determinado, con el fin de plantear la estrategia comercial más adecuada.
        p.mt-3 En un mercado se encuentran los siguientes elementos básicos que lo integran:
      .col-6.d-none.d-xl-block
        figure
          img(src="@/assets/template/tema-3-7.png", alt="Texto que describa la imagen")
    .row.mt-4
      .col-10.offset-1.mt-5
        .titulo-sexto.color-acento-contenido
          h5.text-small Figura 4
          p.text-small.italic Aspectos para la realización de un plan de negocio
    .row.mt-5
      .col-10.offset-1.offset-md-0.col-md-6.col-lg-3.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in2
            figure
              img(src="@/assets/template/tema-3-8.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .h4.mt-4.pt-4 Producto
            p.mt-2 Son los bienes y servicios que se ofrecen en el mercado.                  
      .col-10.offset-1.offset-md-0.col-md-6.col-lg-3.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in2
            figure
              img(src="@/assets/template/tema-3-9.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .h4.mt-4.pt-4 Precio
            p.mt-2 Es el importe a cambio del cual se ofrece un producto.
            
      .col-10.offset-1.offset-md-0.col-md-6.col-lg-3.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in2
            figure
              img(src="@/assets/template/tema-3-10.svg", alt="Texto que describa la imagen").w-50.margin-0-auto
            .h4.mt-4 Clientes potenciales
            p.mt-2 Son las personas físicas, empresas, entidades, etc., que pueden llegar a comprar los productos que ofrece una empresa.
            
      .col-10.offset-1.offset-md-0.col-md-6.col-lg-3.px-4
        .row.rounded-15.box-shadow.h-350-px
          .col-12.p-4.text-center.zoom-in2
            figure
              img(src="@/assets/template/tema-3-11.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
            .h4.mt-4.pt-4 Competencia
            p.mt-2 Es la concurrencia de diferentes oferentes de productos similares en el mismo mercado.
    separador.mt-3

    .titulo-segundo.mt-5
      #t_3_3.h2 3.3  	Segmentación de mercados
    figure.mt-5
      img(src="@/assets/template/tema-3-12.png", alt="Texto que describa la imagen") 
    p.mt-5 La segmentación consiste en dividir el mercado en grupos de compradores con características similares. Se puede establecer según diferentes criterios:
    .row.mt-5 
      .row.mb-2.text-center
        .offset-3.col-sm-6.p-1.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3             
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-13.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Geográficos
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4    
                  .h4.pt-4 Geográficos
                  p.mt-3 Barrio, localidad, provincia, zonas cálidas o frías, etc.
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.text-center.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3             
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-13.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Geográficos
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4    
                  .h4.pt-4 Geográficos
                  p.mt-3 Barrio, localidad, provincia, zonas cálidas o frías, etc.
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-14.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Demográficos 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Demográficos
                  p.mt-3.mb-5 Edad, sexo, etc.
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.text-center.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-14.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Demográficos 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Demográficos
                  p.mt-3.mb-5 Edad, sexo, etc. 
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-15.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Personales  
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Personales 
                  p.mt-3 Estilo de vida, profesión, ingresos, cultura, etc. 
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-15.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Personales  
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Personales 
                  p.mt-3 Estilo de vida, profesión, ingresos, cultura, etc. 
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-16.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Familiares
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Familiares
                  p.mt-3 Tamaño y estructura de las familias, situación, etc.
        .col-sm-6.col-lg-2.tarjeta-flip-tema-2.p-1.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-16.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Familiares
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Familiares
                  p.mt-3 Tamaño y estructura de las familias, situación, etc.
    .row.mt-3
      .row.mb-5.text-center
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3             
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-17.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Psicológicos 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4    
                  .h4.pt-4 Psicológicos 
                  p.mt-3 Motivaciones de compra, actitud ante el producto, etc. 
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.text-center.offset-1.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3             
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-17.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Psicológicos 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4    
                  .h4.pt-4 Psicológicos 
                  p.mt-3 Motivaciones de compra, actitud ante el producto, etc. 
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-18.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Conductuales 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Conductuales
                  p.mt-3.mb-5 Fidelidad a un producto o marca, regularidad de compra, etc. 
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.text-center.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-18.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Conductuales 
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-5    
                  .h4.pt-3 Conductuales
                  p.mt-3.mb-5 Fidelidad a un producto o marca, regularidad de compra, etc. 
        .col-sm-6.p-1.offset-3.text-center.d-block.d-lg-none
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-19.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Por uso   
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4   
                  .h4.pt-3 Por uso  
                  p.mt-3 Da lugar a segmentos tales como grandes usuarios, medianos usuarios, usuarios ocasionales y no usuarios. 
        .col-sm-6.col-lg-3.tarjeta-flip-tema-2.p-1.d-none.d-lg-block
          .tarjeta.tarjeta-flip(@mouseover="indicadorTarjetaFlip = false").box-shadow
            .tarjeta-flip__contenedor
              .tarjeta-flip__img.p-3            
                .row.align-self-center   
                  figure.pt-3
                    img(src="@/assets/template/tema-3-19.svg", alt="Texto que describa la imagen").w-50.margin-0-auto.px-3
                  .h4.mt-4 Por uso   
              .tarjeta-flip__contenido.p-3.bg-azul-claro
                .row.pt-4   
                  .h4.pt-3 Por uso  
                  p.mt-3 Da lugar a segmentos tales como grandes usuarios, medianos usuarios, usuarios ocasionales y no usuarios. 
    .row.mt-1
      .col-10.col-lg-8.offset-1.offset-lg-2
        .bloque-texto-a.color-secundario.p-4.p-md-4 
          .row.m-0.align-items-center.justify-content-between
            .col-lg-8
              .bloque-texto-a__texto.p-4
                p Una vez realizada la segmentación, la unidad productiva deberá elegir la franja de mercado con mayor volumen de ventas, mayores expectativas de crecimiento, menor competencia y mayores beneficios para dirigirse al mercado, el cual será la meta. El mercado meta está compuesto por un grupo de compradores potenciales que la unidad productiva buscará convertir en clientes. 
            .col-lg-4.mb-4.mb-lg-0.d-none.d-lg-block
              figure
                img(src="@/assets/template/tema-3-20.svg", alt="Texto que describa la imagen").floating.w-75.margin-0-auto
    .titulo-segundo.mt-5
      #t_3_4.h2 3.4  	Competencia
    .row.mt-5.position-relative
      .col-10.offset-1.d-block.d-lg-none.bg-acento-botones.rounded-20.px-5.py-4
        p Para que exista una posibilidad de que la unidad productiva obtenga éxito con sus productos o servicios, se debe conocer muy bien quienes son los competidores más cercanos y cómo desarrollan su actividad, las características de sus productos, los precios, su comercialización y que aceptación tienen en el mercado. De esta forma resulta más fácil la toma de decisiones al momento de incursionar un producto propio al mercado. 
        p.mt-3 De lo anterior es necesario conceptualizar y entonces poder definir a la competencia como la concurrencia en el mismo mercado de distintos oferentes de bienes y servicios. Para poder analizar a la competencia, se debe conocer:
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right.naranja
            | Un análisis y descripción de los productos y servicios de los competidores como los propios.
          li 
            i.fas.fa-angle-right.naranja
            | Destacar los puntos fuertes, los débiles y realizar la respectiva comparación.
          li 
            i.fas.fa-angle-right.naranja
            | Conocer el número de las empresas que están en el mercado al que vamos a acceder y conocer de igual forma las ventas de cada una (registros mercantiles, informes comerciales, etc.).
      
      .col-8.align-self-center.d-none.d-lg-block.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 0%; padding-top: 2%; padding-bottom:2%")
        p Para que exista una posibilidad de que la unidad productiva obtenga éxito con sus productos o servicios, se debe conocer muy bien quienes son los competidores más cercanos y cómo desarrollan su actividad, las características de sus productos, los precios, su comercialización y que aceptación tienen en el mercado. De esta forma resulta más fácil la toma de decisiones al momento de incursionar un producto propio al mercado. 
        p.mt-3 De lo anterior es necesario conceptualizar y entonces poder definir a la competencia como la concurrencia en el mismo mercado de distintos oferentes de bienes y servicios. Para poder analizar a la competencia, se debe conocer:
        ul.lista-ul.mt-3
          li 
            i.fas.fa-angle-right.naranja
            | Un análisis y descripción de los productos y servicios de los competidores como los propios.
          li 
            i.fas.fa-angle-right.naranja
            | Destacar los puntos fuertes, los débiles y realizar la respectiva comparación.
          li 
            i.fas.fa-angle-right.naranja
            | Conocer el número de las empresas que están en el mercado al que vamos a acceder y conocer de igual forma las ventas de cada una (registros mercantiles, informes comerciales, etc.).
      .col-6.offset-6.d-none.d-lg-block
        figure
          img(src="@/assets/template/tema-3-21.png", alt="Texto que describa la imagen")
    .titulo-segundo.mt-5
      #t_3_5.h2 3.5 	Estrategias y acciones
    figure.mt-5
      img(src="@/assets/template/tema-3-22.png", alt="Texto que describa la imagen") 
    p.mt-5 Una vez que tenemos definidos los segmentos, se pueden aplicar tres tipos de estrategias de segmentación diferentes:
    .row.mt-5
      .col-8.offset-2
        .cajon.color-primario.p-4.mb-4.bg-azul-30 
          .row            
            .h4 Intentamos          
            p Amoldar el producto a las necesidades de cada segmento. Este tipo de política exige desembolsos importantes y es más propio de empresas grandes. Es la estrategia que utilizan; por ejemplo, los fabricantes de autos sacando al mercado distintas gamas de vehículos para diferentes niveles adquisitivos.
    .row.mt-4
      .col-8.offset-2
        .cajon.color-primario.p-4.mb-4.bg-azul-20 
          .row            
            .h4 Indiferenciada     
            p A todos los segmentos se les da el mismo producto, esto es, no diferenciar.
    .row.mt-4
      .col-8.offset-2
        .cajon.color-primario.p-4.mb-4.bg-azul-10 
          .row            
            .h4 Concentrada    
            p Se queda con un segmento y acopla el producto a sus necesidades.
    .row.mt-4
      .col-8.offset-2
        .bloque-texto-g.color-primario.p-3.p-sm-4.p-md-4.mb-5
          .bloque-texto-g__img(
            :style="{'background-image': `url(${require('@/assets/template/tema-3-23.png')})`}"
          )
          .bloque-texto-g__texto.p-4
            p.mb-0 En la actualidad, con los avances tecnológicos y la revolución de las comunicaciones, muchas de las grandes unidades productivas u organizaciones buscan aplicar diferentes estrategias de marketing que le permitan posicionarse y mantenerse en el mercado. Algunas de estas estrategias de marketing son: 
    TabsB.color-acento-secundario.mt-5
      .py-4.py-md-5(titulo="Nuevos formatos de contenido " :icono="require('@/assets/template/tema-3-24.svg')")
        .row
          .col-7
            .h4 Nuevos formatos de contenido 
            p.mt-3 Las imágenes y videos consiguen más interacción que una publicidad con texto y en el contexto actual es habitual verse o compartirse estos recursos por redes sociales. Algunos medios novedosos están los videos 360°, <em>live photos</em>, realidad virtual, etc.
          .col-5
            figure
              img(src="@/assets/template/tema-3-28.svg", alt="Imagen ilustrativa")
      .py-4.py-md-5(titulo="Públicos similares " :icono="require('@/assets/template/tema-3-25.svg')")
        .row
          .col-7
            .h4  Públicos similares 
            p.mt-3 La audiencia similar es un gran aliado para encontrar nuevos clientes. Se prioriza al cliente objetivo y esto se da por medio de plataformas o aplicaciones de redes sociales que permiten publicar contenidos comerciales, estas compañías identifican los públicos similares en la app y dirige la publicidad a esas personas, logrando así un aumento en las ventas y que nuevos clientes visiten la unidad productiva. 
          .col-5
            figure
              img(src="@/assets/template/tema-3-29.svg", alt="Imagen ilustrativa")
      .py-4.py-md-5(titulo="Actualización y creatividad " :icono="require('@/assets/template/tema-3-26.svg')")
        .row
          .col-7
            .h4  Actualización y creatividad 
            p.mt-3 El mundo digital y las redes sociales se encuentran en constante evolución y cada día las unidades productivas deben mantenerse a la vanguardia de todo lo que se da en el mundo tecnológico. Aquí es importante que la unidad productiva este actualizando y consultando lo último en publicaciones, diseños y medios de comunicación.
          .col-5
            figure
              img(src="@/assets/template/tema-3-30.svg", alt="Imagen ilustrativa").w-75.margin-0-auto
      .py-4.py-md-5(titulo="Manejo de plataformas digitales " :icono="require('@/assets/template/tema-3-27.svg')")
        .row
          .col-7
            .h4  Manejo de plataformas digitales 
            p.mt-3 Es fundamental que toda unidad productiva tenga canales de comunicación y manejen redes sociales propias de la entidad. Se debe manejar diferentes tipos de contenidos publicitarios de la unidad productiva y deben ser de constante comunicación o rotación de la información.
          .col-5
            figure
              img(src="@/assets/template/tema-3-31.svg", alt="Imagen ilustrativa")
</template>

<script>
import Botones from '../components/Botones.vue'
export default {
  name: 'Tema3',
  components: {
    Botones,
  },
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
