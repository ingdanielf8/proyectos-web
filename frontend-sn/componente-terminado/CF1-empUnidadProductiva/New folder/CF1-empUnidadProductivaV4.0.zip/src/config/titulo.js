module.exports = 'Planificación de unidades productivas'
