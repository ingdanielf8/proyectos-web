<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 6
      h1 Mercadeo y servicios
    figure.mt-5
      img(src="@/assets/template/tema-6-1.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-12.col-lg-10
        p La planeación estratégica de mercado se relaciona con la asignación de recursos que son escasos y de los que se desea obtener un rendimiento o utilidad. Esta toma de decisión busca alcanzar metas y definir caminos para lograr el objetivo deseado.
        p.mt-3 En esta planeación se debe tener presente la misión y la definición del negocio, para establecer el campo de acción en el marco de productos y servicios (tecnología), clientes y necesidades satisfechas.
      .col-4.offset-4.offset-lg-0.col-lg-2.align-self-center
        figure
          img(src="@/assets/template/tema-6-2.svg", alt="Texto que describa la imagen").w-75.margin-0-auto.floating
    separador.mt-3
    .titulo-segundo.mt-5
      #t_6_1.h2 6.1  	Servicios
    .row.mt-5
      .col-12.col-lg-8
        p Los servicios representan, cada vez más, una parte integral del producto. Por otro lado, sin un producto tangible para mostrar a los clientes, los vendedores de servicios deben ser hábiles en las estrategias de marketing para crear valor para sus consumidores.
        .row.mt-4  
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row 
                .col-3.align-self-center.d-none.d-lg-block
                  figure
                    img(src="@/assets/template/tema-6-3.svg", alt="Texto que describa la imagen").w-75.margin-0-auto
                .col-12.col-lg-9.align-self-center
                  p.text-small Un servicio se considera una acción de hacer algo por alguien o algo. Es en gran medida intangible (no material) y es por esta razón que se convierte en un gran reto para toda unidad productiva. Debe existir en la unidad productiva una cultura de servicio. Esta no solo debe ir dirigida a sus clientes sino también a sus empleados, pues internamente los empleados también son clientes que pueden estar insatisfechos y al momento de realizar sus actividades o la venta puede no convencer del todo al cliente externo sobre los productos o servicios. Es aquí donde se hace necesario conocer la identidad y apropiación de los empleados con la empresa y para esto se debe capacitar a los empleados y brindarles toda la información necesaria sobre los servicios y productos de la unidad productiva. 
        p.mt-4 Por otra parte, en relación a los clientes, es importante tener presente la orientación del consumidor como elemento diferenciador para mejorar en los servicios prestados y características de los productos. Es aquí donde se debe medir la relación beneficio-empleado-cliente donde les brinde a estos agentes de participar en las decisiones la construcción de una planificación estratégica de la unidad productiva.
      .col-4.offset-4.offset-lg-0.mt-4.mt-lg-0.align-self-center
        figure
          img(src="@/assets/template/tema-6-4.png", alt="Texto que describa la imagen")
    separador.mt-3
    .titulo-segundo.mt-5
      #t_6_2.h2 6.2  	Características 
    figure.mt-5
      img(src="@/assets/template/tema-6-5.png", alt="Texto que describa la imagen") 
    p.mt-5 En las características del servicio como marketing, se encuentran en su orden: 
    .row.mt-5
      .col-12.col-lg-8.offset-lg-2
        LineaTiempoD.color-primario
          .row(numero="1" titulo="Perecedero:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-6.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p No se puede poner el servicio en el depósito o almacén de inventario.
              p.mt-3 Un ejemplo claro de esto pasa con las aerolíneas cuando después de haber despegado el avión no pueden vender ese asiento nuevamente y es por esta razón que deben vender a un precio máximo los asientos en horas pico. Esto se hace para disminuir los costos y obtener ganancias.
          .row(numero="2" titulo="Variabilidad:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-7.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p No habrá dos servicios idénticos pues existe el factor de variabilidad.
              p.mt-3 Un ejemplo de esto se da cuando se compara la experiencia y nivel de satisfacción al observar el grupo de música favorita en DVD varias veces y el poder asistir a un concierto en más de una vez, evidenciando entonces que la experiencia será diferente porque las actuaciones no serán idénticas.
          .row(numero="3" titulo="Homogéneo:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-8.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Por lo general los servicios son los mismos.
              p.mt-3 Aquí un ejemplo claro son los restaurantes de cadena como Mcdonald’s, KFC y Burguer King que ofrecen la misma experiencia en cualquier tienda ubicada en diferentes regiones o países, siempre van a encontrar la misma presentación y calidad de los productos.
          .row(numero="4" titulo="Inseparable:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-9.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Va desde el punto donde se consume y desde el proveedor del servicio. 
              p.mt-3 En esta característica se resalta que el consumo es inseparable de la producción. Un ejemplo sería el servicio prestado por un salón de belleza o estilista, donde el consumidor puede decir si mejora el corte o mejorar el cambio de imagen.
          .row(numero="5" titulo="Intangible:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-10.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p No tiene presencia física real como lo hace un producto. 
              p.mt-3 Aquí se puede ver el ejemplo de los seguros de automóviles que mantienen un certificado y su servicio financiero no se toca. Aquí es difícil conocer la calidad del servicio antes de consumirlo, lo que se diferencia de un producto.
    separador.mt-3
    
    .titulo-segundo.mt-5
      #t_6_3.h2 6.3  	Marcos de referencia y buenas prácticas
    .row.mt-5.position-relative
      .col-10.offset-1.d-block.d-no-none.bg-acento-botones.rounded-20.px-5.py-4
        p El buen servicio que se ofrezca en una unidad productiva es determinante para que tus antiguos consumidores les cuenten a nuevos clientes su experiencia y recomendaciones de los productos y servicios.
        .row.mx-0.mt-3
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row 
                p.text-small Aquí es importante que los clientes se lleven una buena experiencia porque de lo contrario pueden llegar a contarlo a otros posibles clientes futuros, lo que provocaría una reducción de las ventas y rentabilidad. 
        p.mt-3 Por otra parte, cuando se hace referencia a las buenas prácticas empresariales, se traduce en las acciones que se realizan en un periodo de tiempo determinado y genera una mejora en continua en los productos, servicio o situación que se encuentre la unidad productiva. Está relacionado al concepto de responsabilidad corporativa y en este es crucial el compromiso de todos los que hacen parte de la organización, como: directivos, proveedores, trabajadores, comunidad local, entre otros que intervienen en el funcionamiento de la unidad productiva. 
        p.mt-3 Entre todas estas acciones que se despliegan de las buenas prácticas se encuentran:
        ul.lista-ul.mt-3.mt-3.text-small
          li 
            i.fas.fa-angle-right.naranja
            | Satisfacción en cada servicio ofrecido, por ambas partes.
          li 
            i.fas.fa-angle-right.naranja
            | I+D+I: investigación, desarrollo e innovación.
          li 
            i.fas.fa-angle-right.naranja
            | Mantener transparencia y sinceridad en los procesos.
          li 
            i.fas.fa-angle-right.naranja
            | Calidad y relación con el precio.
          li 
            i.fas.fa-angle-right.naranja
            | Búsqueda de la mejora continua a través de nuevos modelos de negocio, producción.
          li 
            i.fas.fa-angle-right.naranja
            | Resolución de cualquier acontecimiento.
          li 
            i.fas.fa-angle-right.naranja
            | Inversión en marketing y comunicación.
          li 
            i.fas.fa-angle-right.naranja
            | Comunicación continua con los clientes y potenciales clientes.
          li 
            i.fas.fa-angle-right.naranja
            | Buena atención al cliente durante todo el proceso de compra.
          li 
            i.fas.fa-angle-right.naranja
            | Desarrollo y aporte a la comunidad local.
      
      .col-8.align-self-center.d-none.d-lg-block.bg-acento-botones.rounded-20.px-5.position-absolute(style="left: 33%; padding-top: 3%; padding-bottom:3%; top:4%")
        p El buen servicio que se ofrezca en una unidad productiva es determinante para que tus antiguos consumidores les cuenten a nuevos clientes su experiencia y recomendaciones de los productos y servicios.
        .row.mx-0.mt-3
          .col-12
            .cajon.color-acento-contenido.p-4.mb-4 
              .row 
                p.text-small Aquí es importante que los clientes se lleven una buena experiencia porque de lo contrario pueden llegar a contarlo a otros posibles clientes futuros, lo que provocaría una reducción de las ventas y rentabilidad. 
        p.mt-3 Por otra parte, cuando se hace referencia a las buenas prácticas empresariales, se traduce en las acciones que se realizan en un periodo de tiempo determinado y genera una mejora en continua en los productos, servicio o situación que se encuentre la unidad productiva. Está relacionado al concepto de responsabilidad corporativa y en este es crucial el compromiso de todos los que hacen parte de la organización, como: directivos, proveedores, trabajadores, comunidad local, entre otros que intervienen en el funcionamiento de la unidad productiva. 
        p.mt-3 Entre todas estas acciones que se despliegan de las buenas prácticas se encuentran:
        ul.lista-ul.mt-3.mt-3.text-small
          li 
            i.fas.fa-angle-right.naranja
            | Satisfacción en cada servicio ofrecido, por ambas partes.
          li 
            i.fas.fa-angle-right.naranja
            | I+D+I: investigación, desarrollo e innovación.
          li 
            i.fas.fa-angle-right.naranja
            | Mantener transparencia y sinceridad en los procesos.
          li 
            i.fas.fa-angle-right.naranja
            | Calidad y relación con el precio.
          li 
            i.fas.fa-angle-right.naranja
            | Búsqueda de la mejora continua a través de nuevos modelos de negocio, producción.
          li 
            i.fas.fa-angle-right.naranja
            | Resolución de cualquier acontecimiento.
          li 
            i.fas.fa-angle-right.naranja
            | Inversión en marketing y comunicación.
          li 
            i.fas.fa-angle-right.naranja
            | Comunicación continua con los clientes y potenciales clientes.
          li 
            i.fas.fa-angle-right.naranja
            | Buena atención al cliente durante todo el proceso de compra.
          li 
            i.fas.fa-angle-right.naranja
            | Desarrollo y aporte a la comunidad local.
      .col-6.d-none.d-lg-block
        figure
          img(src="@/assets/template/tema-6-11.png", alt="Texto que describa la imagen")
    separador.mt-3
    .titulo-segundo.mt-5
      #t_6_4.h2 6.4  	Herramientas de gestión 
    .row.mt-1
      .col-10.col-lg-8.offset-1.offset-lg-2
        .bloque-texto-a.color-secundario.p-4.p-md-4 
          .row.m-0.align-items-center.justify-content-between
            .col-lg-8
              .bloque-texto-a__texto.p-4
                p En la industria manufacturera, el método Kaizen considera muchos pasos; sin embargo, las herramientas para mejorar la satisfacción del cliente no son muy comunes. Para el mejoramiento de los procesos, algunos métodos utilizados son las (7) herramientas de control de calidad:
            .col-lg-4.mb-4.mb-lg-0.d-none.d-lg-block
              figure
                img(src="@/assets/template/tema-6-12.svg", alt="Texto que describa la imagen").floating.w-75.margin-0-auto
    .row.mt-5
      .col-12.col-lg-8.offset-lg-2
        LineaTiempoD.color-primario
          .row(numero="1" titulo="Lista de chequeo:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-13.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Antes de la satisfacción del cliente se debe verificar el estado actual mediante una lista de chequeo que describa la calidad, servicio, limpieza, marketing, entre otros.
          .row(numero="2" titulo="Satisfacción de los empleados:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-14.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Se debe mejorar la satisfacción del empleado para mejorar la satisfacción del cliente pues este es atendido por el empleado.
          .row(numero="3" titulo="Análisis de satisfacción del cliente:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-15.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Se debe encuestar al cliente para conocer su nivel de satisfacción, después de esto se buscan los factores en que se debe mejorar.
          .row(numero="4" titulo="<i>Benchmarking</i>:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-16.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Aquí se debe investigar y conocer las empresas competitivas del sector para identificar las brechas y mejorar las prácticas de la unidad productiva.
          .row(numero="5" titulo="Hoja de combinación de trabajo estándar:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-17.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Este se deriva del toyotismo, en él se elimina el desperdicio, la reducción de espera, los desplazamientos y defectos que se puedan dar en la unidad productiva.
          .row(numero="6" titulo="Actividad de 5S:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-18.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Esta es la primera actividad de toda empresa manufacturera o de servicios y hace referencia a la limpieza frecuente de los establecimientos.
          .row(numero="7" titulo="Manual de servicio:")
            .col-2.pt-4
              figure
                img(src="@/assets/template/tema-6-19.svg", alt="Imagen ilustrativa")
            .col-10.pt-4
              p Su objetivo es eliminar las diferencias en el nivel de servicio al cliente entre los diferentes empleados.

</template>

<script>
export default {
  name: 'Tema6',
  components: {},
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
