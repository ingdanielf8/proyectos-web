module.exports = 'Introducción al desarrollo de aplicaciones móviles'
