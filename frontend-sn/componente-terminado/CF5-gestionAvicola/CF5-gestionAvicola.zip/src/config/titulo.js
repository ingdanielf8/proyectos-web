module.exports = 'Procesos contables y financieros de la empresa avícola'
