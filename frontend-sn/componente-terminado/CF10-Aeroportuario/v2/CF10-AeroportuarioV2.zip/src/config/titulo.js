module.exports = 'Manejo del proceso de equipajes en lengua inglesa'
