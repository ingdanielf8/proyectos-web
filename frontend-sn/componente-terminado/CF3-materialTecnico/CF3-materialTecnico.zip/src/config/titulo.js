module.exports =
  'Contexto, cronograma y diseño de estrategias de ciberseguridad'
