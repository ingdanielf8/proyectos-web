module.exports = 'Bases de datos NoSQL'
