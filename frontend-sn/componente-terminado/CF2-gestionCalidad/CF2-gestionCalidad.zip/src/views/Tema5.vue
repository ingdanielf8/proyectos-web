<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 5
      h1 Riesgos
    .row.mt-5.bg-image
      .col-6.p-5
        p Es importante tener muy en cuenta que las organizaciones son, como las define North (1990), economista norteamericano nacido en Cambridge, “grupos de individuos vinculados por la intención común de lograr metas”. Teniendo en cuenta esto y conociendo lo relevante de las acciones que dirijan a las empresas al mejoramiento continuo, se debe empezar con una evaluación de capacidades, cuyo objetivo es “ofrecer una idea clara de la capacidad de un país o de un sector en términos de puntos fuertes o débiles y de activos de los que dispone. Se trata de un enfoque estructurado para el análisis de la capacidad en tres dimensiones: individuos, organizaciones y entorno favorable” (FAO, 2015). Posterior a esta gestión, se puede realizar el análisis organizacional, con el fin de lograr o ahondar en un conocimiento más recóndito de lo que puede ocasionar fragilidad a la empresa y encontrar oportunidades de mejora. Para conseguir esto, se deben considerar factores culturales, políticos y de intereses internos. 
    p.mt-5 Hay siete etapas muy relevantes para llevar a cabo una buena evaluación organizacional, que son:
    .row.mt-5(data-aos="flip-up")
      .col-8
        LineaTiempoD.color-acento-botones
          .row(numero="1" titulo="Analizar y confirmar las expectativas con respecto al uso de  los hallazgos")
            .col-2
              figure
                img(src='@/assets/template/tema-5-2.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Identificar las expectativas de los actores clave respecto a cómo será usada la información que surja como producto del análisis.
          .row(numero="2" titulo="Verificar qué se cuente con las habilidades necesarias ")
            .col-2
              figure
                img(src='@/assets/template/tema-5-3.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 La imparcialidad, experiencia organizacional, sensibilidad, conocimiento de la industria o, en definitiva, la idoneidad de los consultores es muy importante al momento de dar su concepto sobre la evaluación.
          .row(numero="3" titulo="Asegurar que exista soporte y compromiso en la alta dirección de la empresa")
            .col-2
              figure
                img(src='@/assets/template/tema-5-4.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Debe existir compromiso y dirección por parte de la gerencia de la empresa, pero no debe ser el único miembro involucrado en la evaluación organizacional.
          .row(numero="4" titulo="Usar un marco de referencia probado")
            .col-2
              figure
                img(src='@/assets/template/tema-5-5.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Fundamental que se haga uso de un marco de referencia y de herramientas de evaluación muy bien probados en el pasado, con certeza de que no se escapen elementos críticos, y de que existan unas muy buenas bases en teoría que sustenten lo que se analice y se recomiende. 
          .row(numero="5" titulo="Asegurar que se cuenta con información precisa y completa")
            .col-2
              figure
                img(src='@/assets/template/tema-5-6.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Se hace necesario que haya un gran y experimentado equipo de evaluación y que el mismo cuente con los siguientes pasos:
              ul.lista-ul
                li 
                  i.fas.fa-angle-right
                  | Muy buena selección de consultores. 
                li.mt-2 
                  i.fas.fa-angle-right
                  | Compromiso total de directivas y personal.
                li.mt-2 
                  i.fas.fa-angle-right
                  | Asegurar que la información venga de diversas fuentes, no de unas pocas o de una sola.
          .row(numero="6" titulo="Verificar la confidencialidad y propiedad de la información resultante")
            .col-2
              figure
                img(src='@/assets/template/tema-5-7.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Tener muy claro desde el inicio quién tiene los derechos sobre la evaluación efectuada, a pesar de que haya muchas personas y organizaciones interesadas en esos resultados.
          .row(numero="7" titulo="Actuar y/o tomar decisiones con la información recaudada")
            .col-2
              figure
                img(src='@/assets/template/tema-5-8.svg', alt='Texto que describa la imagen').w-75.margin-0-auto
            .col-10
              p.mt-3 Uno de los resultados más importantes del proceso de evaluación es el documento que describe la situación actual y, con ella, los hallazgos más importantes. En este documento, se encuentran las fortalezas y las debilidades actuales y, a partir de allí, se debe desarrollar un plan de acciones a corto, mediano y largo plazo.
      .col-4
        figure
          img(src='@/assets/template/tema-5-9.png', alt='Texto que describa la imagen')
    .row(data-aos="slide-left").mt-5
      .col-12
        .cajon.color-secundario.p-4.mb-4
          .row
            .col-7
              p La norma que rige la calidad del mejoramiento continuo de una empresa está dada por la GTC-ISO 9004-2018 Guía Técnica Colombiana. Gestión de la calidad. Calidad de una organización orientada para lograr el éxito sostenido. 
              p.mt-3  ISO (Organización Internacional de Normalización) es una federación mundial de organismos nacionales de normalización (organismos miembros de ISO). El trabajo de elaboración de las Normas Internacionales se lleva a cabo normalmente a través de los comités técnicos de ISO. Cada organismo miembro interesado en una materia para la cual se haya establecido un comité técnico tiene el derecho de estar representado en dicho comité. Las organizaciones internacionales, gubernamentales y no gubernamentales, vinculadas con ISO también participan en el trabajo y colaboran estrechamente con la Comisión Electrotécnica Internacional (IEC) en todos los temas de normalización electrotécnica. (ICONTEC, 2018)
            .col-5
              figure
                img(src="@/assets/template/tema-5-10.png", alt="Texto que describa la imagen")
    .row.mt-5(data-aos="flip-up")
      .col-10.offset-1
        .tarjeta.color-secundario.p-3.mb-5
          .row.justify-content-around.align-items-center
            .col-3.col-sm-2.col-lg-2
              img(src="@/assets/template/tema-5-11.svg").w-75.margin-0-auto
            .col
              .row
                .col-12.py-3
                  .row.justify-content-between.align-items-center
                    .col.mb-3.mb-sm-0
                      h3.mb-1 Guìa_Tènica_Colombiana_GTC-ISO 9004:2018  
                      p.text-small.mb-0.mt-2 Para afianzar sus conocimientos en la norma orientada a lograr el éxito sostenido en la empresa, diríjase a la carpeta    
                      p.text-small #[strong Anexos/ Anexo1_NTC-ISO- 9004 2018 _Guia_Tecnica_Colombiana_ orientación para lograr el éxito sostenido.pdf]  
                    .col-sm-auto
                      a.boton.color-acento-contenido(:href="obtenerLink('/downloads/prueba.pdf')" target="_blank")
                        span.text-rojo Descargar
                        i.fas.fa-file-download.text-rojo
    BotonesB(data-aos="fade-up")
    separador(style="margin-top: 12rem")


    .titulo-segundo
      #t_5_1.h2 5.2  Importancia del presupuesto como mejora continua
    .row.mt-5.zoom-in
      .col-7
        p El Ministerio del Trabajo, comprometido con las políticas de protección de los trabajadores colombianos y en desarrollo de las normas y convenios internacionales, estableció el Sistema de Gestión de Seguridad y Salud en el Trabajo (SG-SST), el cual debe ser implementado por todos los empleadores, y consiste en el desarrollo de un proceso lógico y por etapas, basado en la mejora continua, lo cual incluye la política, la organización, la planificación, la aplicación, la evaluación, la auditoría y las acciones de mejora, con el objetivo de anticipar, reconocer, evaluar y controlar los riesgos que puedan afectar la seguridad y la salud en los espacios laborales.
        p.mt-3 El sistema de gestión aplica a todos los empleadores públicos y privados, los trabajadores dependientes e independientes, los trabajadores cooperados, los trabajadores en misión, los contratantes de personal bajo modalidad de contrato civil, comercial o administrativo, las organizaciones de economía solidaria y del sector cooperativo, las empresas de servicios temporales, las agremiaciones o asociaciones que afilian trabajadores independientes al Sistema de Seguridad Social Integral; las administradoras de riesgos laborales; la Policía Nacional, en lo que corresponde a su personal no uniformado y al personal civil de las Fuerzas Militares. Institucional y jurídicamente, fue determinado mediante Decreto 1072 de 2015 Libro 2, Parte 2, Título 4, Capítulo 6. 
        p.mt-3 De acuerdo con los lineamientos establecidos desde el marco normativo, se invita a socializar la conferencia web1 del Sistema de gestión de seguridad y salud en el trabajo (SG-SST).
      .col-5
        figure
          img(src="@/assets/template/tema-5-13.svg", alt="Texto que describa la imagen")
    .row.mt-5(data-aos="flip-up")
      .col-10.offset-1
        .tarjeta.color-secundario.p-3.mb-5
          .row.justify-content-around.align-items-center
            .col-3.col-sm-2.col-lg-2
              img(src="@/assets/template/tema-5-14.svg").w-75.margin-0-auto
            .col
              .row
                .col-12.py-3
                  .row.justify-content-between.align-items-center
                    .col.mb-3.mb-sm-0
                      h3.mb-1 Conferencia Web 1  SGSST  
                      p.text-small.mb-0.mt-2 Para afianzar sus conocimientos en la normatividad del sistema de gestión de seguridad y salud en el trabajo, le invitamos a ver la video conferencia  web en la url 
                      a #[strong https://www.youtube.com/watch?v=_pv-B5YDWBQ]
                    .col-sm-auto
                      a.boton.color-acento-contenido(:href="obtenerLink('https://www.youtube.com/watch?v=_pv-B5YDWBQ')" target="_blank")
                        span.text-rojo Enlace web
                        i.fas.fa-link.text-rojo
</template>

<script>
import BotonesB from '../components/BotonesB.vue'
export default {
  name: 'Tema5',
  components: {
    BotonesB,
  },
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
