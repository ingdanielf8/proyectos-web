module.exports = 'Entorno, diagnóstico y conocimiento de empresa.'
