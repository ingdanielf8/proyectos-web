module.exports = 'Conceptos, tecnologías y arquitectura para el desarrollo web.'
