module.exports = 'Entrega continua'
