module.exports = 'Conceptos generales de bases de datos'
