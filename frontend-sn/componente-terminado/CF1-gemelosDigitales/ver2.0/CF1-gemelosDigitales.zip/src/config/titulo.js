module.exports =
  'Componente Formativo con un nombre extremadamente largo y extenso'
