module.exports = 'Plan de comunicación integral'
