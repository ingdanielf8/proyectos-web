<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    .titulo-principal
      .titulo-principal__numero
        span 2
      h1 Comunicación integral
    .row.mt-5
      .col
        .cajon.color-primario.p-4.mb-4.bg-rojo-claro
          .row
            .col-md-4
              figure
                img(src='@/assets/template/tema-2-1.png', alt='Texto que describa la imagen')
            .col-md-8
              p.mt-4 El mercado global está compuesto por un grupo complejo de competidores que luchan por conseguir clientes en un entorno que cambia con suma rapidez. Ante la complejidad y saturación del mercado, las empresas tratan de hacerse oír. Los expertos de marketing saben que la comunicación de una empresa debe hablar con voz clara. Los clientes deben entender la esencia de una empresa y los beneficios de los bienes y servicios que produce. Con la creciente variedad de canales de promoción y publicidad y tantas empresas bombardeando con mensajes a los posibles clientes, la tarea representa todo un reto. #[strong (Clow y Baack, 2010).]
    p.mt-5 El término Comunicación Integral de Marketing (CIM) se refiere a la coordinación e integración de todas las herramientas, vías y fuentes de comunicación de marketing de una empresa dentro de un programa uniforme que maximice el impacto sobre los clientes y otras partes interesadas a un costo mínimo. Esta integración afecta toda la comunicación de empresa a empresa, canal de marketing, centrada en los clientes y dirigida al interior de una empresa. #[strong (Clow y Baack, 2010).]
    figure.mt-5
      .video
        iframe(width="560" height="315" src="https://www.youtube.com/embed/ZtS0dRaNtfM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    .row.mt-5
      .col-12.py-4.px-5.bg-amarillo-claro.borde-izq-amarillo
        .h6 Puntos de contacto  
        p.mt-4 Las comunicaciones integradas de marketing requieren que se reconozcan todos los puntos de contacto donde el cliente puede encontrar información sobre la compañía y sus marcas. Cada contacto con la marca transmitirá un mensaje —ya sea favorable, desfavorable o indiferente—. La meta de la empresa debe ser transmitir un mensaje consistente y positivo en cada contacto. 
    .row.mt-4
      .col-12.py-4.px-5.bg-amarillo-claro.borde-der-amarillo
        .h6 Comunicaciones integradas
        p.mt-4 Las comunicaciones integradas de marketing unifican todos los mensajes y las imágenes de la compañía. De esa forma, los anuncios de televisión e impresos comunican el mismo mensaje que sus mensajes de correo electrónico y sus comunicaciones de ventas personales. #[strong (Kotler y Armstrong, 2017).]
    .row.mt-5
      .col-12.py-4.px-5.bg-amarillo-claro.borde-izq-amarillo
        .h6 Combinación de los canales de comunicación
        p.mt-4 Es frecuente que las empresas no integren los diversos canales de comunicación, las herramientas, los mensajes, generando una combinación difícil de asimilar por el consumidor final. En este sentido, los mensajes contradictorios pueden provocar imágenes confusas de la empresa y un posicionamiento de marca borroso, lo que en última instancia hace complicadas las relaciones con los clientes.
    .row.mt-4
      .col-12.py-4.px-5.bg-amarillo-claro.borde-der-amarillo
        .h6 Mensaje claro, coherente y convincente
        p.mt-4 Según #[strong Kotler y Armstrong (2013)], las comunicaciones integradas de marketing (CIM) implican la integración cuidadosa y coordinada de todos los canales de comunicación que la empresa utiliza, para entregar un mensaje claro, coherente y convincente sobre la organización y sus productos. En este sentido, se requiere conocer todos los puntos de contacto con el cliente, ya que cada uno genera un mensaje bueno, malo, neutro, claro, coherente y positivo. La estrategia total de comunicación de marketing, encaminada a forjar relaciones con los clientes, mostrando cómo la empresa y su oferta los ayudan a resolver sus problemas y satisfacer sus necesidades.  #[strong (Estrella y Segovia, 2016).]
    p.mt-5 #[strong Estrella y Segovia (2016)] explican a continuación las opciones comunicativas y los canales de comunicación integrada.
    figure.mt-5
      img(src="@/assets/template/tema-2-5.svg", alt="Texto que describa la imagen")
    figcaption Referencia SENA
    .h5.mt-5 Tipos de comunicación integral
    p.mt-5 De acuerdo con #[strong Ocampo (2014)], se describen a continuación los tipos de comunicación que se deben establecer en la organización para la realización de un plan de comunicación integral. 
    TabsB.mt-5
      .py-4.py-md-5(titulo="1.	Comunicación interna ")
        .row
          .col-lg-6.d-none.d-md-block
            figure
              img(src='@/assets/template/tema-2-2.png', alt='Texto que describa la imagen') 
          .col-12.col-lg-6
            .h6 Comunicación interna
            p.mt-4 Se da al interior de la organización y está dispuesta de tres formas:
            .row.mt-3
              .col-12
                ol.lista-ol--cuadro
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white a
                    p #[strong Descendente:] la comunicación de las disposiciones de la gerencia para el desarrollo de funciones, tareas, roles, entrenamiento, capacitación, directivas, directrices, políticas, entre otras. Debe irradiar en todos los niveles de la organización en la relación quién ordena y quién cumple.
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white b
                    p #[strong Ascendente:] regula el clima organizacional e incluye la participación en las decisiones a los empleados. Es necesario que se estimule la convivencia significativa de las personas, donde la realización personal sea el fin de la propia organización.
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white c
                    p #[strong Horizontal:] flujo de información entre las unidades de la organización. Se requiere de una comunicación horizontal entre personas, entre grupos, entre departamentos y entre todos los públicos de la organización, de igual a igual.
      .py-4.py-md-5(titulo="2.	Comunicación externa ")
        .row
          .col-lg-6.d-none.d-md-block
            figure
              img(src='@/assets/template/tema-2-3.png', alt='Texto que describa la imagen') 
          .col-12.col-lg-6
            .h6 Comunicación externa
            p.mt-4 Se da para interrelacionarse con los diferentes públicos de la organización e incluye las siguientes formas:
            .row.mt-3
              .col-12
                ol.lista-ol--cuadro
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white a
                    p #[strong Comunicación comercial:] comprende las relaciones comunicativas que se deben establecer con el cliente, los proveedores, los competidores y los medios de comunicación. Se desprenden las actividades publicitarias de sus productos a través de los medios de comunicación: cuñas radiales, comerciales para televisión y cine, impresos, vallas, anuncios virtuales, etc.
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white b
                    p #[strong Comunicación pública:] se establecen relaciones de obligatoriedad con el gobierno; el pago de impuestos, las disposiciones técnicas y legales, el régimen laboral y las normas ambientales, entre otras. Relaciones con las organizaciones no gubernamentales, con quienes se pudiese establecer procesos de investigación y desarrollo, con miras a la producción de conocimiento. Relaciones con la comunidad, como directo beneficiario de las acciones del orden social de la organización y donde se establece el impacto de las acciones productivas de la misma. Relaciones empresariales, dispuestas por las necesidades de diálogo con los directos competidores y con la finalidad de asociación para la constitución de proyectos, alianzas estratégicas, gremios, etc.
                  li
                    .lista-ol--cuadro__vineta
                      span.text-white c
                    p #[strong Stakeholders:] Por último, relaciones con los públicos denominados stakeholders, considerados como aquellos agentes identificables que en una situación específica podrían condicionar el buen nombre de la organización en perjuicio de su actividad productiva.
    .titulo-segundo.mt-5
      #t_2_1.h4 2.1  Plan de comunicación integral
    .row.borde-gris.p-5
      .col-md-4
        figure
          img(src='@/assets/template/tema-2-4.png', alt='Texto que describa la imagen')
      .col-md-8
        p Se centra muy especialmente en la variable comunicación del mix de marketing. Es un documento que recoge los objetivos y las estrategias de comunicación en todos los ámbitos de la empresa, es decir, haciendo referencia tanto a la comunicación interna como a la externa, y se pretende poner en práctica en el medio-largo plazo. #[strong (Estrella y Segovia, 2016).]
    p.mt-5 El plan de comunicaciones de una organización es de carácter integral donde se incluyan todos los escenarios de la organización, interno y externo. Es un “modelo sinérgico”, ya que sugiere la construcción de una cadena cerrada de relaciones entre los públicos internos y externos de la organización, donde, a partir de la convicción y la motivación como fuentes energéticas del plan de comunicación, se logra el nivel deseado de efectividad corporativa que enriquece simultáneamente a los miembros y a la organización como un todo. 
    p.mt-5 Los pasos para la creación de un plan de comunicación integral, #[strong Clow y Baack (2020)] los describen a continuación:
    .row.mt-5
      .col-12.bg-gris.p-5.text-align-center
        figure
          img(src='@/assets/template/tema-2-6.svg', alt='Texto que describa la imagen')
      figcaption Referencia SENA
    p.mt-5 Cabe resaltar que para la formulación de un plan de comunicación la empresa debe elaborar un documento llamado #[strong briefing], que contiene información relativa al público objetivo, posicionamiento de la marca/empresa, promesa o beneficio del producto/servicio que ofrece la empresa, tono de la comunicación deseado, eje y concepto de la comunicación, presupuesto disponible, etc., que ayude a identificar las necesidades comunicativas de la empresa. 
    .row.mt-5
      .col-12.py-4.px-5.borde-izq-rojo(style='background-color: rgba(214, 70, 38, 0.4) ;')
        .row
          .col-3.d-none.d-md-block.align-self-center
            figure
              img(src='@/assets/template/tema-2-7.png', alt='Texto que describa la imagen')
          .col-12.col-md-9
            .h6 Briefing  
            p.mt-4 Es la base de la estrategia publicitaria e implica la elección, ordenación estratégica y creativa de los datos que permitan definir los objetivos comunicativos de forma concreta, medible y cuantificable. 
    .row.mt-4
      .col-12.py-4.px-5.borde-der-rojo(style='background-color: rgba(214, 70, 38, 0.25) ;')
        .row
          .col-3.d-none.d-md-block.align-self-center
              figure
                img(src='@/assets/template/tema-2-8.png', alt='Texto que describa la imagen')
          .col-12.col-md-9
            .h6 Copy Strategy 
            p.mt-4 Es el centro fundamental del briefing y expresa el beneficio básico que la marca promete, es decir, la promesa o beneficio del producto/servicio que ofrece la empresa. #[strong (Estrella y Segovia, 2016).]
    .row.mt-5
      .col-12.py-4.px-5.borde-izq-rojo(style='background-color: rgba(214, 70, 38, 0.2) ;')
        .row
          .col-3.d-none.d-md-block.align-self-center
              figure
                img(src='@/assets/template/tema-2-9.png', alt='Texto que describa la imagen')
          .col-12.col-md-9
            .h6 Tácticas 
            p.mt-4 Una vez realizado el briefing, se deben pensar y diseñar tácticas o acciones concretas que se desarrollen para cumplir con las estrategias. Con el cumplimiento de estas, se alcanzarán los objetivos generales y, por consiguiente, se cerrará el proceso para el seguimiento del plan de comunicación. 
    .row.mt-4
      .col-12.py-4.px-5.borde-der-rojo(style='background-color: rgba(214, 70, 38, 0.1) ;')
        .row
          .col-3.d-none.d-md-block.align-self-center
              figure
                img(src='@/assets/template/tema-2-10.png', alt='Texto que describa la imagen')
          .col-12.col-md-9
            .h6 Canales online y offline 
            p.mt-4 En el plan se aplica el uso de canales online y offline. Es decir, no hay una separación entre el ámbito digital y el tradicional, puesto que ambos pertenecen a un mismo plan de comunicación. Finalmente, los planes deben implementarse y determinar la medición de acciones como analítica web en redes sociales y los principales KPI. #[strong (Alard y Monfort, 2018).]
    .titulo-segundo.mt-5
      #t_2_2.h4 2.2  Verbatim
    figure
      img(src='@/assets/template/tema-2-11.png', alt='Texto que describa la imagen') 
    p.mt-5 Un #[strong Verbatim] es la utilización de testimoniales dentro de una estrategia de comunicación, lo que permite fortalecer la confianza de los consumidores en el producto o servicio ofertado. Los testimonios de los clientes son una importante referencia ya que indican el nivel de éxito de la marca frente a la audiencia.
    p.mt-4 Los #[strong Verbatim] como «[…] la mayor herramienta comercial de una agencia, sucede cuando se presenta un proyecto y se promueve la realización de acciones nuevas y divertidas, como un festival en la nieve. Ello abre las puertas porque parece que las marcas están aburridas…»
    .row.mt-3
      .col-12
        ol.lista-ol--cuadro
          li
            .lista-ol--cuadro__vineta
              span.text-white a
            | Existen diferentes testimoniales. Pueden ser:
    ul.lista-ul.mt-3
      li.mb-0 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Un texto    
      li.mb-0.mt-2 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Un video donde se demuestra el uso del producto
      li.mb-0.mt-2 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Imágenes con la satisfacción del cliente. 
          li.mt-4
            .lista-ol--cuadro__vineta
              span.text-white b
            | Los testimoniales se pueden utilizar en diferentes medios:
    ul.lista-ul.mt-3
      li.mb-0 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Social media    
      li.mb-0.mt-2 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Correo electrónico
      li.mb-0.mt-2 
        .row
          .col-12
            i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
            | Página o sitio web y se observa el historial de testimonios de clientes satisfechos.
    .titulo-segundo.mt-5
      #t_2_3.h4 2.3  Insight
    .row.mt-5
      .col-10.offset-1.borde-top-gris
        .row.py-4
          .col-3.d-none.d-lg-block.align-self-center
            figure(style='margin-left: 55px; position:relative ; z-index:  99;')
              img(src="@/assets/template/tema-2-12.png", alt="Texto que describa la imagen")
          .col-12.col-lg-9.align-self-center.p-5.rounded(style='background-color: rgba(255, 217, 71, 0.25) ;')
            .row
              .col-11.offset-1
                p.mt-3 Un insight es una experiencia verdadera y relevante para el consumidor que se expresa con el lenguaje del consumidor. Trata de conectar con lo más profundo que hay en él, considerándole siempre como «persona». #[strong (Ayestarán et al., 2012).] 
                p.mt-1 Tanto el equipo creativo (que crea mensajes) como los planeadores de medios (que deciden cómo y cuándo dar el mensaje) necesitan saber todo lo que puedan, tan a fondo y a detalle como sea posible, acerca de las personas a las que tratan de llegar. 
    p.mt-5 La información demográfica y psicológica se utiliza para describir la audiencia meta. El objetivo de la investigación del consumidor es resolver un insight clave que ayude a la audiencia meta a responder al mensaje. 
    .row.mt-5
      .col-12
        ol.lista-ol--cuadro
          li(style="border-bottom: 1px solid #AFAFAF; padding-bottom: 10px;")
            .lista-ol--cuadro__vineta
              span.text-white 1
            | ¿A quiénes está tratando de llegar y qué insight tiene sobre cómo piensan, sienten y actúan? 
          li.mt-4(style="border-bottom: 1px solid #AFAFAF; padding-bottom: 10px;")
            .lista-ol--cuadro__vineta
              span.text-white 2
            | ¿Cómo deberían responder a su mensaje publicitario?
          li.mt-4(style="border-bottom: 1px solid #AFAFAF; padding-bottom: 10px;")
            .lista-ol--cuadro__vineta
              span.text-white 3
            | Un insight clave exhibe el factor de relevancia, es decir, la razón por la que un consumidor se interesa en un mensaje de marca.
          li.mt-4(style="border-bottom: 1px solid #AFAFAF; padding-bottom: 10px;")
            .lista-ol--cuadro__vineta
              span.text-white 4
            p Los insights de los consumidores revelan la naturaleza interna de sus pensamientos como los estados de ánimo, motivaciones, deseos, aspiraciones y motivos que desencadenan sus actitudes y acciones. #[strong (Wells et al. 2007)].
          li.mt-4
            .lista-ol--cuadro__vineta
              span.text-white 5
            | Algunos ejemplos reales de publicidad y el uso de insight:
        ul.lista-ul.mt-3(style="border-bottom: 1px solid #AFAFAF; padding-bottom: 10px;")
          li.mb-0 
            .row
              .col-12
                i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
                | Volkswagen, “El día de la boda es el día más feliz para una mujer,
                p(style="margin-right: .8rem; margin-left: 3.3rem") pero no para su padre”.    
          li.mb-0.mt-2 
            .row
              .col-12
                i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
                | Bancolombia, “En Colombia, todos son hinchas de un equipo local, pero cuando
                p(style="margin-right: .8rem; margin-left: 3.3rem") un jugador de nuestro país juega en el exterior nos volvemos hinchas del jugador”.
          li.mb-0.mt-2 
            .row
              .col-12
                i.fas.fa-angle-right.color-c.text-center(style="margin-right: .8rem; margin-left: 2rem")
                | Mama Luchetti, “Los hijos piden juguetes a diario, las mamás los evitan a diario”.
    .titulo-segundo.mt-5
      #t_2_4.h4 2.4  Percepción
    .row.mt-5
      .col-12.borde-top-gris
        .row.py-4
          .col-3.d-none.d-lg-block.align-self-center
            figure(style='margin-left: 55px; position:relative ; z-index:  99;')
              img(src="@/assets/template/tema-2-13.png", alt="Texto que describa la imagen")
          .col-12.col-lg-9.align-self-center.p-5.rounded(style='background-color: rgba(151, 24, 26, 0.2) ;')
            .row
              .col-11.offset-1
                p.mt-3 Una persona motivada está lista para actuar. La forma en que se comporte estará influida por su propia percepción acerca de la situación. Todos aprendemos gracias al flujo de información que llega a nuestros cinco sentidos: vista, oído, olfato, tacto y gusto. Sin embargo, cada uno de nosotros recibe, organiza e interpreta la información sensorial de manera individual. 
                p.mt-1 La percepción es el proceso mediante el cual las personas seleccionan, organizan e interpretan la información para formarse una imagen significativa del mundo. La gente podría tener distintas percepciones del mismo estímulo debido a tres procesos perceptuales: atención, distorsión y retención selectivas. 
    p.mt-5 Las personas están expuestas a un gran número de estímulos cotidianamente. Por ejemplo, se estima que la gente se expone a una cantidad de anuncios que oscila entre tres mil y cinco mil cada día. El abarrotado entorno digital agrega 5.3 billones de anuncios en línea cada año, 400 millones de tuits que se envían a diario, 144 mil horas de video que se suben diariamente a Internet y 4750 millones de piezas de contenido compartido en Facebook cada día. Es imposible prestar atención a todos esos estímulos que entran en competencia a nuestro alrededor. #[strong (Kotler y Armstrong, 2017).]
    SlyderB.mb-5(:datos="datosSlyder3").mt-5
    










</template>

<script>
export default {
  name: 'Tema2',
  components: {},
  data: () => ({
    datosSlyder3: [
      {
        titulo: 'La atención selectiva',
        texto:
          'Tendencia de los individuos a filtrar la mayor parte de la información a la que se ven expuestos— implica que los especialistas en marketing deben trabajar intensamente para llamar la atención del consumidor. Aún los estímulos percibidos no siempre se captan en la forma deseada. Cada persona ajusta la información de entrada en un esquema mental existente.',
        imagen: require('@/assets/template/tema-2-14.png'),
      },
      {
        titulo: 'La distorsión selectiva ',
        texto:
          'Describe la tendencia de las personas a interpretar la información de manera que sustente sus creencias. La gente olvida también gran parte de lo que aprende; suele retener información que reafirma sus actitudes y creencias. ',
        imagen: require('@/assets/template/tema-2-15.png'),
      },
      {
        titulo: 'La retención selectiva ',
        texto:
          'Implica que los consumidores probablemente recuerden los aspectos positivos de una marca que prefieren y olviden los de las marcas competidoras. ',
        imagen: require('@/assets/template/tema-2-16.png'),
      },
    ],
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
