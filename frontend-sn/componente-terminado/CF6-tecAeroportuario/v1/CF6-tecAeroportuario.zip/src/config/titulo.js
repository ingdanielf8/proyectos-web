module.exports = 'Registro y embarque al viajero'
