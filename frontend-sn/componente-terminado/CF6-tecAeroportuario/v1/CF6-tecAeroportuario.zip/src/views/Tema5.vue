<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5
    
    .titulo-principal
      .titulo-principal__numero
        span 5
      h1 Salas VIP
    .row.mt-5
      .col-12.col-lg-9
        p Estos espacios son destinados para los clientes que requieren por su estatus un trato personalizado y especial; por lo tanto, se les brinda mayor comodidad y confort, ya que normalmente para las aerolíneas son clientes de alto valor por lo cual es importante brindarles todos los atributos diseñados por la línea aérea.
        p.mt-3 Son lugares exclusivos de las aerolíneas y en algunos casos tienen alianzas con bancos para viajeros con tarjetas de crédito de alto nivel que permiten esperar su vuelo degustando deliciosos platos, dormir una siesta, darse una ducha o relajarse en un spa.
      .col-4.col-lg-3.offset-4.offset-lg-0
        figure
          img(src="@/assets/template/tema-5-1.png", alt="Texto que describa la imagen")
    .row.text-center.mt-5
      .h4 Sala VIP Iberia en el Aeropuerto Internacional Barajas de Madrid España
    figure.mt-5
      img(src="@/assets/template/tema-5-2.png", alt="Texto que describa la imagen")
    .row.mt-5
      .col-10.offset-1
        .bloque-texto-a.color-secundario.p-4.p-md-4.mb-5 
          .row.m-0.align-items-center.justify-content-between
            .col-lg-9
              .bloque-texto-a__texto.p-4
                .h4 Generalidades y características
                p.mt-2 La mayoría de las salas VIP ofrecen salas totalmente equipadas con wifi, computadoras, tv, impresoras, enchufes y snack bar. También suelen ofrecer material de lectura en los salones y asistencia del personal de la aerolínea para cualquier duda, bonificaciones en estacionamiento y agilización de trámites migratorios y embarque preferencial. Muchas salas de aeropuertos internacionales tienen salas para dormir, las cuales incluyen dormitorios amplios y duchas para tomar el siguiente vuelo sin el estrés que pudo haber causado el vuelo anterior si es un vuelo en conexión. Las salas más lujosas pueden tener buffet con comida deliciosa y hasta spa, algunas salas tienen espacios para juegos con actividades y televisión para los niños.
            .col-lg-3.mb-4.mb-lg-0
              figure
                img(src="@/assets/template/tema-5-3.svg", alt="Texto que describa la imagen")
    .h4.mt-5 Generalidades
    p.mt-5 Los clientes que podrán utilizar estos espacios son normalmente los que cumplen con alguna de las siguientes condiciones: 
    ul.lista-ul.mt-5
      li 
        i.fas.fa-angle-right
        | Clientes que adquieran cabina ejecutiva o de primera clase para las aerolíneas que manejan esta cabina.
      li 
        i.fas.fa-angle-right
        | Socio elite del programa de lealtad de la aerolínea o de la alianza si esta está dentro de alguna.
      li 
        i.fas.fa-angle-right
        | Acompañante de un socio elite.
      li 
        i.fas.fa-angle-right
        | Si la Sala VIP tiene convenio con bancos o franquicias y el viajero tiene tarjetas de crédito de alta categoría.
      li 
        i.fas.fa-angle-right
        | Algunas Salas VIP permiten hacer el pago de un pase diario para acceder; sin embargo, estas están sujetas a condiciones y restricciones.
      li 
        i.fas.fa-angle-right
        | En ocasiones los programas de lealtad de las aerolíneas permiten redimir millas para tener accesos a las Salas VIP.
    p.mt-5 Para iniciar la atención en salas VIP inicie dando la bienvenida a cada uno de los clientes que visite la sala, solicite los documentos de identidad y los que lo acrediten como beneficiario del uso de esta sala y realice el registro de ingreso a la sala del cliente.
    .h4.mt-5 Características
    p.mt-5 Estas salas son lugares exclusivos de algunas líneas aéreas que le permiten esperar al cliente su vuelo en un ambiente cómodo y por lo general con deliciosos platillos, bebidas y entretenimiento lo que hace más amable la experiencia de viaje y crea estatus para la persona que puede acceder.
    p.mt-4 Algunos de los servicios que el pasajero podrá encontrar en las salas VIP, son:
    ol.lista-ol--cuadro.mt-5
      li 
        .lista-ol--cuadro__vineta
          span 1
        .col-12
          p.mb-0 Solicitud de ascensos de cortesía.
      li 
        .lista-ol--cuadro__vineta
          span 2
        .col-12
          p.mb-0 Cambios de vuelo.
      li 
        .lista-ol--cuadro__vineta
          span 3
        .col-12
          p.mb-0 Sala de espera exclusiva.
      li 
        .lista-ol--cuadro__vineta
          span 4
        .col-12
          p.mb-0 Bebidas nacionales e Internacionales.
      li 
        .lista-ol--cuadro__vineta
          span 5
        .col-12
          p.mb-0 Platillos y pasa bocas.
      li 
        .lista-ol--cuadro__vineta
          span 6
        .col-12
          p.mb-0 Prensa.
      li 
        .lista-ol--cuadro__vineta
          span 7
        .col-12
          p.mb-0 Entretenimiento.
      li 
        .lista-ol--cuadro__vineta
          span 8
        .col-12
          p.mb-0 Snacks.
      li 
        .lista-ol--cuadro__vineta
          span 9
        .col-12
          p.mb-0 Tecnología. 
      li 
        .lista-ol--cuadro__vineta
          span 10
        .col-12
          p.mb-0 Zonas familiares.
      li 
        .lista-ol--cuadro__vineta
          span 11
        .col-12
          p.mb-0 Salas de reuniones.
    .row.mt-5.text-center
      .h4 Sala VIP Aeropuerto Internacional Mourian de Qatar Airways, en Doha (DOH)
    figure.mt-5
      img(src="@/assets/template/tema-5-4.png", alt="Texto que describa la imagen")
    .row.mt-5.text-center
      .h4 Restaurante Sala VIP Aeropuerto Internacional Mourian de Qatar Airways, en Doha (DOH)
    figure.mt-5
      img(src="@/assets/template/tema-5-5.png", alt="Texto que describa la imagen")
    .row.mt-5.text-center
      .h4 Sala de Descanso Sala VIP Aeropuerto Internacional Mourian de Qatar Airways, en Doha (DOH)
    figure.mt-5
      img(src="@/assets/template/tema-5-6.png", alt="Texto que describa la imagen")
    .row.mt-5.text-center
      .h4 Sala de Juntas Sala VIP Aeropuerto Internacional Mourian de Qatar Airways, en Doha (DOH)
    figure.mt-5
      img(src="@/assets/template/tema-5-7.png", alt="Texto que describa la imagen")



</template>

<script>
export default {
  name: 'Tema5',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass" scoped></style>
